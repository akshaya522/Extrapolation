
Imports System.Math
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Drawing.Graphics
Imports System.Windows.Forms.PaintEventArgs
Imports System.Threading



Public Class DK_LOT

    Inherits System.Windows.Forms.Form
    Private sInfoFile As String = "../tmpInfo.ini"
    Private sResultsFile As String = "../tmpResult.ini"
    Private sSetupFile As String = "../tmpSetup.ini"
    Private sEarningsFile As String = "../tmpEarnings.ini"
    Private sStageFile As String = "../tmpStage.ini"
    Friend WithEvents LotteryB As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents AmountA1 As System.Windows.Forms.Label
    Friend WithEvents AmountA2 As System.Windows.Forms.Label
    Friend WithEvents ChooseA As System.Windows.Forms.Button
    Friend WithEvents ChooseB As System.Windows.Forms.Button
    Friend WithEvents AmountB1 As System.Windows.Forms.Label
    Friend WithEvents AmountB2 As System.Windows.Forms.Label
    Friend WithEvents IDlabel As System.Windows.Forms.Label
    Friend WithEvents AmountB3 As Label
    Friend WithEvents AmountA3 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Dim brushes(5) As System.Drawing.SolidBrush



#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Header As System.Windows.Forms.Label
    Friend WithEvents LotteryA As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Header = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.LotteryA = New System.Windows.Forms.PictureBox()
        Me.LotteryB = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AmountA1 = New System.Windows.Forms.Label()
        Me.AmountA2 = New System.Windows.Forms.Label()
        Me.ChooseA = New System.Windows.Forms.Button()
        Me.ChooseB = New System.Windows.Forms.Button()
        Me.AmountB1 = New System.Windows.Forms.Label()
        Me.AmountB2 = New System.Windows.Forms.Label()
        Me.IDlabel = New System.Windows.Forms.Label()
        Me.AmountB3 = New System.Windows.Forms.Label()
        Me.AmountA3 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.LotteryA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LotteryB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(347, 601)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(166, 90)
        Me.Button1.TabIndex = 52
        Me.Button1.Text = "Forts�t"
        '
        'Header
        '
        Me.Header.Font = New System.Drawing.Font("Garamond", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header.Location = New System.Drawing.Point(92, 9)
        Me.Header.Name = "Header"
        Me.Header.Size = New System.Drawing.Size(733, 32)
        Me.Header.TabIndex = 16
        Me.Header.Text = "testing"
        Me.Header.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(11, 124)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(302, 31)
        Me.Label22.TabIndex = 16
        Me.Label22.Text = "Venstre"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LotteryA
        '
        Me.LotteryA.Location = New System.Drawing.Point(15, 158)
        Me.LotteryA.Name = "LotteryA"
        Me.LotteryA.Size = New System.Drawing.Size(303, 300)
        Me.LotteryA.TabIndex = 44
        Me.LotteryA.TabStop = False
        '
        'LotteryB
        '
        Me.LotteryB.Location = New System.Drawing.Point(534, 158)
        Me.LotteryB.Name = "LotteryB"
        Me.LotteryB.Size = New System.Drawing.Size(300, 300)
        Me.LotteryB.TabIndex = 45
        Me.LotteryB.TabStop = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(535, 124)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(299, 31)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "H�jre"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'AmountA1
        '
        Me.AmountA1.Font = New System.Drawing.Font("Garamond", 12.25!)
        Me.AmountA1.Location = New System.Drawing.Point(11, 463)
        Me.AmountA1.Name = "AmountA1"
        Me.AmountA1.Size = New System.Drawing.Size(377, 41)
        Me.AmountA1.TabIndex = 47
        Me.AmountA1.Text = "Lottery Valgmulighed A"
        Me.AmountA1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AmountA2
        '
        Me.AmountA2.Font = New System.Drawing.Font("Garamond", 12.25!)
        Me.AmountA2.Location = New System.Drawing.Point(10, 504)
        Me.AmountA2.Name = "AmountA2"
        Me.AmountA2.Size = New System.Drawing.Size(378, 41)
        Me.AmountA2.TabIndex = 48
        Me.AmountA2.Text = "Lottery Valgmulighed A"
        Me.AmountA2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ChooseA
        '
        Me.ChooseA.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChooseA.Location = New System.Drawing.Point(15, 601)
        Me.ChooseA.Name = "ChooseA"
        Me.ChooseA.Size = New System.Drawing.Size(166, 90)
        Me.ChooseA.TabIndex = 49
        Me.ChooseA.Text = "V�lg venstre"
        Me.ChooseA.UseVisualStyleBackColor = True
        '
        'ChooseB
        '
        Me.ChooseB.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChooseB.Location = New System.Drawing.Point(668, 601)
        Me.ChooseB.Name = "ChooseB"
        Me.ChooseB.Size = New System.Drawing.Size(166, 90)
        Me.ChooseB.TabIndex = 50
        Me.ChooseB.Text = "V�lg h�jre"
        Me.ChooseB.UseVisualStyleBackColor = True
        '
        'AmountB1
        '
        Me.AmountB1.Font = New System.Drawing.Font("Garamond", 12.25!)
        Me.AmountB1.Location = New System.Drawing.Point(456, 463)
        Me.AmountB1.Name = "AmountB1"
        Me.AmountB1.Size = New System.Drawing.Size(397, 41)
        Me.AmountB1.TabIndex = 53
        Me.AmountB1.Text = "Lottery Valgmulighed A"
        Me.AmountB1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AmountB2
        '
        Me.AmountB2.Font = New System.Drawing.Font("Garamond", 12.25!)
        Me.AmountB2.Location = New System.Drawing.Point(456, 504)
        Me.AmountB2.Name = "AmountB2"
        Me.AmountB2.Size = New System.Drawing.Size(397, 41)
        Me.AmountB2.TabIndex = 52
        Me.AmountB2.Text = "Lottery Valgmulighed A"
        Me.AmountB2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'IDlabel
        '
        Me.IDlabel.AutoSize = True
        Me.IDlabel.Font = New System.Drawing.Font("Garamond", 14.0!, System.Drawing.FontStyle.Bold)
        Me.IDlabel.Location = New System.Drawing.Point(11, 9)
        Me.IDlabel.Name = "IDlabel"
        Me.IDlabel.Size = New System.Drawing.Size(72, 21)
        Me.IDlabel.TabIndex = 54
        Me.IDlabel.Text = "IDlabel"
        '
        'AmountB3
        '
        Me.AmountB3.Font = New System.Drawing.Font("Garamond", 12.25!)
        Me.AmountB3.Location = New System.Drawing.Point(456, 545)
        Me.AmountB3.Name = "AmountB3"
        Me.AmountB3.Size = New System.Drawing.Size(397, 41)
        Me.AmountB3.TabIndex = 56
        Me.AmountB3.Text = "Lottery Valgmulighed A"
        Me.AmountB3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AmountA3
        '
        Me.AmountA3.Font = New System.Drawing.Font("Garamond", 12.25!)
        Me.AmountA3.Location = New System.Drawing.Point(10, 545)
        Me.AmountA3.Name = "AmountA3"
        Me.AmountA3.Size = New System.Drawing.Size(378, 41)
        Me.AmountA3.TabIndex = 55
        Me.AmountA3.Text = "Lottery Valgmulighed A"
        Me.AmountA3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(733, 23)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "testing"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Garamond", 14.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(12, 91)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(733, 23)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "testing"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DK_LOT
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(859, 721)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.AmountB3)
        Me.Controls.Add(Me.AmountA3)
        Me.Controls.Add(Me.IDlabel)
        Me.Controls.Add(Me.AmountB1)
        Me.Controls.Add(Me.AmountB2)
        Me.Controls.Add(Me.ChooseB)
        Me.Controls.Add(Me.ChooseA)
        Me.Controls.Add(Me.AmountA2)
        Me.Controls.Add(Me.AmountA1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LotteryB)
        Me.Controls.Add(Me.LotteryA)
        Me.Controls.Add(Me.Header)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label22)
        Me.Name = "DK_LOT"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.LotteryA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LotteryB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region
    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                             "GetPrivateProfileStringA" (ByVal lpApplicationName _
                             As String, ByVal lpKeyName As String, ByVal lpDefault _
                             As String, ByVal lpReturnedString As String, ByVal _
                             nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub


    Private Sub DK_LOT(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        ' OK button is inaktive
        Me.Button1.Enabled = False

        ' Find out which lottery is played
        Dim Task As Integer = sGetINI(sInfoFile, "RAtask", "Task", 1)
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")

        Me.IDlabel.Text = "ID: " & userId


        Me.Header.Text = "Beslutning " & Task & " af 40"

        ' Dim lottery information
        Dim strtempA As String = "RAtask " & Task

        Dim tempPrizeA1 As Single
        Dim tempPrizeA2 As Single
        Dim tempPrizeA3 As Single
        Dim tempPrizeB1 As Single
        Dim tempPrizeB2 As Single
        Dim tempPrizeB3 As Single

        Dim tempProbA1 As Single
        Dim tempProbA2 As Single
        Dim tempProbA3 As Single
        Dim tempProbB1 As Single
        Dim tempProbB2 As Single
        Dim tempProbB3 As Single

        ' Update basic lottery
        tempPrizeA1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeA1", 0))
        tempPrizeA2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeA2", 0))
        tempPrizeA3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeA3", 0))
        tempPrizeB1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeB1", 0))
        tempPrizeB2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeB2", 0))
        tempPrizeB3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeB3", 0))
        tempProbA1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbA1", "0")) * 100
        tempProbA2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbA2", "0")) * 100
        tempProbA3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbA3", "0")) * 100
        tempProbB1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbB1", "0")) * 100
        tempProbB2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbB2", "0")) * 100
        tempProbB3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbB3", "0")) * 100

        ' add lotteries of same amount together 
        If tempPrizeA1 = tempPrizeA2 Then
            tempProbA1 = tempProbA1 + tempProbA2
            tempProbA2 = 0
        End If
        If tempPrizeA1 = tempPrizeA3 Then
            tempProbA1 = tempProbA1 + tempProbA3
            tempProbA3 = 0
        End If
        If tempPrizeA2 = tempPrizeA3 Then
            tempProbA2 = tempProbA2 + tempProbA3
            tempProbA3 = 0
        End If

        ' next compounting ... move third prize to second prize if second prize is emplty
        If tempProbA2 = 0 And tempProbA3 > 0 Then
            tempProbA2 = tempProbA3
            tempPrizeA2 = tempPrizeA3
            tempProbA3 = 0
            tempPrizeA3 = 0
        End If

        If tempPrizeB1 = tempPrizeB2 Then
            tempProbB1 = tempProbB1 + tempProbB2
            tempProbB2 = 0
        End If
        If tempPrizeB1 = tempPrizeB3 Then
            tempProbB1 = tempProbB1 + tempProbB3
            tempProbB3 = 0
        End If
        If tempPrizeB2 = tempPrizeB3 Then
            tempProbB2 = tempProbB2 + tempProbB3
            tempProbB3 = 0
        End If

        If tempProbB2 = 0 And tempProbB3 > 0 Then
            tempProbB2 = tempProbB3
            tempPrizeB2 = tempPrizeB3
            tempProbB3 = 0
            tempPrizeB3 = 0
        End If


        Dim endowment As Single = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "endowment", 0))

        If endowment > 0 Then
            Label3.Text = "I dette valg er du garanteret at modtage " & (endowment) & " kroner."
            Label4.Text = "Hvis du taber penge i lotteries, vil tabet blive trukket fra dette bel�b."
        Else
            Label3.Visible = False
            Label4.Visible = False
        End If
        Dim lottery As String = sGetINI(sSetupFile, strtempA, "lottery", 0)

        Dim slicesA As Integer = 0
        Dim slicesB As Integer = 0
        If tempProbA1 > 0 Then
            slicesA = slicesA + 1
        End If
        If tempProbA2 > 0 Then
            slicesA = slicesA + 1
        End If
        If tempProbA3 > 0 Then
            slicesA = slicesA + 1
        End If

        If tempProbB1 > 0 Then
            slicesB = slicesB + 1
        End If
        If tempProbB2 > 0 Then
            slicesB = slicesB + 1
        End If
        If tempProbB3 > 0 Then
            slicesB = slicesB + 1
        End If

        ' Now the Pie text 
        Select Case tempProbA1
            Case > 0
                Me.AmountA1.Text = tempPrizeA1 & " kr." & " hvis terningerne viser 1 til " & tempProbA1 & " (" & tempProbA1 & " % Chance)"
            Case = 0
                Me.AmountA1.Visible = False
        End Select

        Select Case tempProbA2
            Case > 0
                Me.AmountA2.Text = tempPrizeA2 & " kr." & " hvis terningerne viser " & 1 + tempProbA1 & " til " & tempProbA1 + tempProbA2 & " (" & tempProbA2 & " % Chance)"
            Case = 0
                Me.AmountA2.Visible = False
        End Select

        Select Case tempProbA3
            Case > 0
                Me.AmountA3.Text = tempPrizeA3 & " kr." & " hvis terningerne viser " & 1 + tempProbA1 + tempProbA2 & " til " & tempProbA1 + tempProbA2 + tempProbA3 & " (" & tempProbA3 & " % Chance)"
            Case = 0
                Me.AmountA3.Visible = False
        End Select

        Select Case tempProbB1
            Case > 0
                Me.AmountB1.Text = tempPrizeB1 & " kr." & " hvis terningerne viser 1 til " & tempProbB1 & " (" & tempProbB1 & " % Chance)"
            Case = 0
                Me.AmountB1.Visible = False
        End Select

        Select Case tempProbB2
            Case > 0
                Me.AmountB2.Text = tempPrizeB2 & " kr." & " hvis terningerne viser " & 1 + tempProbB1 & " til " & tempProbB1 + tempProbB2 & " (" & tempProbB2 & " % Chance)"
            Case = 0
                Me.AmountB2.Visible = False
        End Select

        Select Case tempProbB3
            Case > 0
                Me.AmountB3.Text = tempPrizeB3 & " kr." & " hvis terningerne viser " & 1 + tempProbB1 + tempProbB2 & " til " & tempProbB1 + tempProbB2 + tempProbB3 & " (" & tempProbB3 & " % Chance)"
            Case = 0
                Me.AmountB3.Visible = False
        End Select


        Me.AmountA1.BackColor = GetColor(0)
        Me.AmountA2.BackColor = GetColor(1)
        Me.AmountA3.BackColor = GetColor(2)

        Me.AmountA1.BorderStyle = BorderStyle.FixedSingle
        Me.AmountA2.BorderStyle = BorderStyle.FixedSingle
        Me.AmountA3.BorderStyle = BorderStyle.FixedSingle

        'Declare object variables
        Dim i As Integer

        'Build a BitMap that will act as the picture
        ' Size of picture
        Dim objBitMapA As New Bitmap(300, 300)

        'Declare your Graphics objects for painting graphics on you newly created bitmap.
        Dim objGraphicsA As Graphics
        objGraphicsA = System.Drawing.Graphics.FromImage(objBitMapA)

        'Set the background color to transparent
        objGraphicsA.Clear(Color.Transparent)

        'Set Probabilities for the pie
        Dim symbolLegA As PointF = New PointF(335, 20)
        Dim descLegA As PointF = New PointF(360, 16)
        Dim sglCurrentAngleA As Single = 0
        Dim sglTotalAngleA As Single = 0

        ' Create font and brush.
        Dim drawFont As New Font("Garamont", 13)
        Dim drawBrush As New SolidBrush(Color.Black)

        ' Set format of string.
        Dim drawFormat As New StringFormat
        drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft
        Dim drawString As String

        Select Case slicesA
            Case 1
                Dim arrValuesA0(0) As Integer
                arrValuesA0(0) = 100
                For i = 0 To arrValuesA0.Length - 1
                    objGraphicsA.FillRectangle(New SolidBrush(GetColor(i)), symbolLegA.X, symbolLegA.Y, 20, 10)
                    objGraphicsA.DrawRectangle(Pens.Black, symbolLegA.X, symbolLegA.Y, 20, 10)
                    symbolLegA.Y += 15
                    descLegA.Y += 15
                Next i
                i = 0
                For i = 0 To arrValuesA0.Length - 1
                    'Current Value / (sum of all the Values) * 360 degree angle
                    sglCurrentAngleA = (arrValuesA0(i) / 100) * 360
                    objGraphicsA.FillPie(New SolidBrush(GetColor(i)), 10, 10, 280, 280, sglTotalAngleA, sglCurrentAngleA)
                    objGraphicsA.DrawPie(Pens.Black, 10, 10, 280, 280, sglTotalAngleA, sglCurrentAngleA)
                    If i = 0 Then
                        drawString = Convert.ToString(tempPrizeA1) & " kr."
                    ElseIf i = 1 Then
                        drawString = Convert.ToString(tempPrizeA2) & " kr."
                    Else
                        drawString = Convert.ToString(tempPrizeA3) & " kr."
                    End If
                    If sglCurrentAngleA > 0 Then
                        Dim angle As Single = ((5 + sglTotalAngleA + sglCurrentAngleA / 2) / 180) * Math.PI
                        Dim localXX As Single = Round((25 * Math.Cos(angle)))
                        If localXX < 0 Then localXX = localXX - 30
                        Dim localYY As Single = Round((25 * Math.Sin(angle)))
                        Dim localX As Single = 150 + localXX
                        Dim localY As Single = 150 + localYY
                        objGraphicsA.DrawString(drawString, drawFont, New SolidBrush(Color.Black), localX, localY)
                    End If

                    sglTotalAngleA += sglCurrentAngleA
                Next i
            Case Else
                Dim arrValuesA(2) As Integer
                Dim s As Integer = 0
                Select Case tempProbA1
                    Case > 0
                        arrValuesA(s) = Convert.ToSingle(tempProbA1)
                        s = s + 1
                    Case Else
                        arrValuesA(s) = Convert.ToSingle(0)
                        s = s + 1
                End Select
                Select Case tempProbA2
                    Case > 0
                        arrValuesA(s) = Convert.ToSingle(tempProbA2)
                        s = s + 1
                    Case Else
                        s = s + 1
                End Select
                Select Case tempProbA3
                    Case > 0
                        arrValuesA(s) = Convert.ToSingle(tempProbA3)
                        s = s + 1
                    Case Else
                        s = s + 1
                End Select
                For i = 0 To 2
                    objGraphicsA.FillRectangle(New SolidBrush(GetColor(i)), symbolLegA.X, symbolLegA.Y, 20, 10)
                    objGraphicsA.DrawRectangle(Pens.Black, symbolLegA.X, symbolLegA.Y, 20, 10)
                    symbolLegA.Y += 15
                    descLegA.Y += 15
                Next i
                i = 0
                For i = 0 To 2
                    'Current Value / (sum of all the Values) * 360 degree angle
                    sglCurrentAngleA = (arrValuesA(i) / 100) * 360
                    objGraphicsA.FillPie(New SolidBrush(GetColor(i)), 10, 10, 280, 280, sglTotalAngleA, sglCurrentAngleA)
                    objGraphicsA.DrawPie(Pens.Black, 10, 10, 280, 280, sglTotalAngleA, sglCurrentAngleA)
                    sglTotalAngleA += sglCurrentAngleA
                Next i
                sglTotalAngleA = 0
                For i = 0 To 2
                    If i = 0 Then
                        drawString = Convert.ToString(tempPrizeA1) & " kr."
                    ElseIf i = 1 Then
                        drawString = Convert.ToString(tempPrizeA2) & " kr."
                    Else
                        drawString = Convert.ToString(tempPrizeA3) & " kr."
                    End If
                    'Current Value / (sum of all the Values) * 360 degree angle
                    sglCurrentAngleA = (arrValuesA(i) / 100) * 360
                    objGraphicsA.FillPie(New SolidBrush(GetColor(i)), 10, 10, 280, 280, sglTotalAngleA, sglCurrentAngleA)
                    objGraphicsA.DrawPie(Pens.Black, 10, 10, 280, 280, sglTotalAngleA, sglCurrentAngleA)

                    ' find placment from initial starting value and the size of the pie
                    If sglCurrentAngleA > 0 Then
                        Dim angle As Single = (5 + sglTotalAngleA + sglCurrentAngleA / 2) / 180 * Math.PI

                        Dim localXX As Single = Round((75 * Math.Cos(angle)))
                        If localXX < 0 Then localXX = localXX - 30
                        Dim localYY As Single = Round((75 * Math.Sin(angle)))
                        Dim localX As Single = 150 + localXX
                        Dim localY As Single = 150 + localYY
                        objGraphicsA.DrawString(drawString, drawFont, New SolidBrush(Color.Black), localX, localY)
                    End If

                    sglTotalAngleA += sglCurrentAngleA
                Next i

        End Select

        objBitMapA.Save("PieA.Gif")
        Me.LotteryA.Image = objBitMapA

        Me.AmountB1.BackColor = GetColor(0)
        Me.AmountB2.BackColor = GetColor(1)
        Me.AmountB3.BackColor = GetColor(2)

        Me.AmountB1.BorderStyle = BorderStyle.FixedSingle
        Me.AmountB2.BorderStyle = BorderStyle.FixedSingle
        Me.AmountB3.BorderStyle = BorderStyle.FixedSingle

        'Declare object variables

        'Build a BitMap that will act as the picture
        ' Size of picture
        Dim objBitMapB As New Bitmap(300, 300)

        'Declare your Graphics objects for painting graphics on you newly created bitmap.
        Dim objGraphicsB As Graphics
        objGraphicsB = System.Drawing.Graphics.FromImage(objBitMapB)

        'Set the background color to transparent
        objGraphicsB.Clear(Color.Transparent)

        'Set Probabilities for the pie
        Dim symbolLegB As PointF = New PointF(335, 20)
        Dim descLegB As PointF = New PointF(360, 16)
        Dim sglCurrentAngleB As Single = 0
        Dim sglTotalAngleB As Single = 0

        Select Case slicesB
            Case 1
                Dim arrValuesB0(0) As Integer
                arrValuesB0(0) = 100
                For i = 0 To arrValuesB0.Length - 1
                    objGraphicsB.FillRectangle(New SolidBrush(GetColor(i)), symbolLegB.X, symbolLegB.Y, 20, 10)
                    objGraphicsB.DrawRectangle(Pens.Black, symbolLegB.X, symbolLegB.Y, 20, 10)
                    symbolLegB.Y += 15
                    descLegB.Y += 15
                Next i
                i = 0
                For i = 0 To arrValuesB0.Length - 1
                    'Current Value / (sum of all the Values) * 360 degree angle
                    sglCurrentAngleB = (arrValuesB0(i) / 100) * 360
                    objGraphicsB.FillPie(New SolidBrush(GetColor(i)), 10, 10, 280, 280, sglTotalAngleB, sglCurrentAngleB)
                    objGraphicsB.DrawPie(Pens.Black, 10, 10, 280, 280, sglTotalAngleB, sglCurrentAngleB)
                    If i = 0 Then
                        drawString = Convert.ToString(tempPrizeB1) & " kr."
                    ElseIf i = 1 Then
                        drawString = Convert.ToString(tempPrizeB2) & " kr."
                    Else
                        drawString = Convert.ToString(tempPrizeB3) & " kr."
                    End If
                    If sglCurrentAngleA > 0 Then
                        Dim angle As Single = ((5 + sglTotalAngleB + sglCurrentAngleB / 2) / 180) * Math.PI
                        Dim localXX As Single = Round((25 * Math.Cos(angle)))
                        If localXX < 0 Then localXX = localXX - 30
                        Dim localYY As Single = Round((25 * Math.Sin(angle)))
                        Dim localX As Single = 150 + localXX
                        Dim localY As Single = 150 + localYY
                        objGraphicsB.DrawString(drawString, drawFont, New SolidBrush(Color.Black), localX, localY)
                    End If

                    sglTotalAngleB += sglCurrentAngleB
                Next i
            Case Else
                Dim arrValuesB(2) As Integer
                Dim s As Integer = 0
                Select Case tempProbB1
                    Case > 0
                        arrValuesB(s) = Convert.ToSingle(tempProbB1)
                        s = s + 1
                    Case Else
                        arrValuesB(s) = Convert.ToSingle(0)
                End Select
                Select Case tempProbB2
                    Case > 0
                        arrValuesB(s) = Convert.ToSingle(tempProbB2)
                        s = s + 1
                    Case Else
                End Select
                Select Case tempProbB3
                    Case > 0
                        arrValuesB(s) = Convert.ToSingle(tempProbB3)
                        s = s + 1
                    Case Else
                End Select
                For i = 0 To 2
                    objGraphicsB.FillRectangle(New SolidBrush(GetColor(i)), symbolLegB.X, symbolLegB.Y, 20, 10)
                    objGraphicsB.DrawRectangle(Pens.Black, symbolLegB.X, symbolLegB.Y, 20, 10)
                    symbolLegB.Y += 15
                    descLegB.Y += 15
                Next i
                i = 0
                For i = 0 To 2
                    'Current Value / (sum of all the Values) * 360 degree angle
                    sglCurrentAngleB = (arrValuesB(i) / 100) * 360
                    objGraphicsB.FillPie(New SolidBrush(GetColor(i)), 10, 10, 280, 280, sglTotalAngleB, sglCurrentAngleB)
                    objGraphicsB.DrawPie(Pens.Black, 10, 10, 280, 280, sglTotalAngleB, sglCurrentAngleB)
                    sglTotalAngleB += sglCurrentAngleB
                Next i
                sglTotalAngleB = 0
                For i = 0 To 2
                    If i = 0 Then
                        drawString = Convert.ToString(tempPrizeB1) & " kr."
                    ElseIf i = 1 Then
                        drawString = Convert.ToString(tempPrizeB2) & " kr."
                    Else
                        drawString = Convert.ToString(tempPrizeB3) & " kr."
                    End If
                    'Current Value / (sum of all the Values) * 360 degree angle
                    sglCurrentAngleB = (arrValuesB(i) / 100) * 360
                    objGraphicsB.FillPie(New SolidBrush(GetColor(i)), 10, 10, 280, 280, sglTotalAngleB, sglCurrentAngleB)
                    objGraphicsB.DrawPie(Pens.Black, 10, 10, 280, 280, sglTotalAngleB, sglCurrentAngleB)

                    ' find placment from initial starting value and the size of the pie
                    If sglCurrentAngleB > 0 Then
                        Dim angle As Single = (5 + sglTotalAngleB + sglCurrentAngleB / 2) / 180 * Math.PI

                        Dim localXX As Single = Round((75 * Math.Cos(angle)))
                        If localXX < 0 Then localXX = localXX - 30
                        Dim localYY As Single = Round((75 * Math.Sin(angle)))
                        Dim localX As Single = 150 + localXX
                        Dim localY As Single = 150 + localYY
                        objGraphicsB.DrawString(drawString, drawFont, New SolidBrush(Color.Black), localX, localY)
                    End If

                    sglTotalAngleB += sglCurrentAngleB
                Next i

        End Select

        objBitMapB.Save("PieB.Gif")
        Me.LotteryB.Image = objBitMapB


    End Sub

    Private Sub Button1_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim Task As Integer = sGetINI(sInfoFile, "RAtask", "Task", 1)
        Dim strtemp As String = "RAtask " & Task

        ' Dim lottery information
        Dim strtempA As String = "RAtask " & Task

        Dim tempPrizeA1 As Single
        Dim tempPrizeA2 As Single
        Dim tempPrizeA3 As Single
        Dim tempPrizeB1 As Single
        Dim tempPrizeB2 As Single
        Dim tempPrizeB3 As Single

        Dim tempProbA1 As Single
        Dim tempProbA2 As Single
        Dim tempProbA3 As Single
        Dim tempProbB1 As Single
        Dim tempProbB2 As Single
        Dim tempProbB3 As Single

        ' Update basic lottery
        tempPrizeA1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeA1", 0))
        tempPrizeA2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeA2", 0))
        tempPrizeA3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeA3", 0))
        tempPrizeB1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeB1", 0))
        tempPrizeB2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeB2", 0))
        tempPrizeB3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "prizeB3", 0))
        tempProbA1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbA1", "0")) * 100
        tempProbA2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbA2", "0")) * 100
        tempProbA3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbA3", "0")) * 100
        tempProbB1 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbB1", "0")) * 100
        tempProbB2 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbB2", "0")) * 100
        tempProbB3 = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbB3", "0")) * 100

        ' add lotteries of same amount together 
        If tempPrizeA1 = tempPrizeA2 Then
            tempProbA1 = tempProbA1 + tempProbA2
            tempProbA2 = 0
        End If
        If tempPrizeA1 = tempPrizeA3 Then
            tempProbA1 = tempProbA1 + tempProbA3
            tempProbA3 = 0
        End If
        If tempPrizeA2 = tempPrizeA3 Then
            tempProbA2 = tempProbA2 + tempProbA3
            tempProbA3 = 0
        End If

        ' next compounting ... move third prize to second prize if second prize is emplty
        If tempProbA2 = 0 And tempProbA3 > 0 Then
            tempProbA2 = tempProbA3
            tempPrizeA2 = tempPrizeA3
            tempProbA3 = 0
            tempPrizeA3 = 0
        End If

        If tempPrizeB1 = tempPrizeB2 Then
            tempProbB1 = tempProbB1 + tempProbB2
            tempProbB2 = 0
        End If
        If tempPrizeB1 = tempPrizeB3 Then
            tempProbB1 = tempProbB1 + tempProbB3
            tempProbB3 = 0
        End If
        If tempPrizeB2 = tempPrizeB3 Then
            tempProbB2 = tempProbB2 + tempProbB3
            tempProbB3 = 0
        End If

        If tempProbB2 = 0 And tempProbB3 > 0 Then
            tempProbB2 = tempProbB3
            tempPrizeB2 = tempPrizeB3
            tempProbB3 = 0
            tempPrizeB3 = 0
        End If


        Dim endowment As Single = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "endowment", 0))

        Dim choiceTC As Single = 0
        Dim choiceA As Integer = 0
        If Me.LotteryA.BorderStyle = BorderStyle.Fixed3D Then
            If Me.LotteryB.BorderStyle = BorderStyle.None Then
                choiceA = 1
                choiceTC = 1
            End If
        End If

        Dim choiceB As Integer = 0
        If Me.LotteryB.BorderStyle = BorderStyle.Fixed3D Then
            If Me.LotteryA.BorderStyle = BorderStyle.None Then
                choiceB = 1
                choiceTC = 2
            End If
        End If

        Dim lotset As String = sGetINI(sSetupFile, strtempA, "lotset", 0)
        Dim pair As String = sGetINI(sSetupFile, strtempA, "pair", 0)
        Dim loss As String = sGetINI(sSetupFile, strtempA, "loss", 0)
        Dim mixed As String = sGetINI(sSetupFile, strtempA, "loss", 0)
        Dim qid As String = sGetINI(sSetupFile, strtempA, "lotset", 0)

        WriteToFile("RA", Task, tempPrizeA1, tempPrizeA2, tempPrizeA3, tempPrizeB1, tempPrizeB2, tempPrizeB3, tempProbA1, tempProbA2, tempProbA3, tempProbB1, tempProbB2, tempProbB3, endowment, qid, mixed, loss, lotset, pair, choiceA, choiceB, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

        ' Write to Temporary ResultsFile
        writeINI(sResultsFile, "ChoiceL", Task, choiceTC)

        ' Now update to the next task
        writeINI(sInfoFile, "RAtask", "Task", Task + 1)

        'check if there is another task
        Task = Task + 1

        Select Case Task
            Case 17
                Dim DK2009 As New InfoLOTM
                DK2009.MdiParent = Me.MdiParent
                Me.Close()
                DK2009.Show()
                Exit Sub
            Case Else
        End Select

        If Task < 41 Then
            Dim DK2009 As New DK_LOT
            DK2009.MdiParent = Me.MdiParent
            Me.Close()
            DK2009.Show()
        Else
            Dim returnPSW As String = "0"
            Dim passwordString As String = "Indtast adgangskode"
            Dim password As String = "2"
            If password <> "" Then
                Do While password <> returnPSW
                    returnPSW = InputBox(passwordString, "Adgangskode", "", 100, 100)
                Loop
            End If
            writeINI(sStageFile, "Stage", "Stage", "LOT_RESULTS")

            Dim DK2009 As New DK_LOT_RESULTS
            DK2009.MdiParent = Me.MdiParent
            Me.Close()
            DK2009.Show()


        End If
    End Sub
    Private Sub WriteToFile(ByVal TaskId As String,
                            ByVal Decision As String,
                            ByVal PrizeA1 As Single,
                            ByVal PrizeA2 As Single,
                            ByVal PrizeA3 As Single,
                            ByVal PrizeB1 As Single,
                            ByVal PrizeB2 As Single,
                            ByVal PrizeB3 As Single,
                            ByVal ProbA1 As Single,
                            ByVal ProbA2 As Single,
                            ByVal ProbA3 As Single,
                            ByVal ProbB1 As Single,
                            ByVal ProbB2 As Single,
                            ByVal ProbB3 As Single,
                            ByVal Endowment As Single,
                            ByVal qid As String,
                            ByVal Mixed As Single,
                            ByVal Loss As Single,
                            ByVal LotSet As Single,
                            ByVal Pair As Single,
                            ByVal ChoiceA As Single,
                            ByVal ChoiceB As Single,
        ByVal ImageN As Single,
        ByVal ProbG As Single,
                            ByVal Points As Single,
                            ByVal pickedprob As Single,
                            ByVal period As Single,
                            ByVal choice1 As Single,
                            ByVal choice2 As Single,
                            ByVal realization As Single,
                            ByVal Question As String,
                            ByVal answer As String,
                            ByVal roll40 As Single,
                            ByVal roll100 As Single,
                            ByVal earnings As Single
                            )

        Dim empty As String = 999

        Dim sFile As StreamWriter
        Dim line As String
        Dim sDate, sTime As String
        sDate = DateString
        sTime = TimeString
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        sFile = File.AppendText("../Data/RA_" & userId & ".txt")
        line = userId & ";" & sDate & ";" & sTime & ";" & TaskId & ";" & Decision & ";" &
            PrizeA1 & ";" & PrizeA2 & ";" & PrizeA3 & ";" & PrizeB1 & ";" & PrizeB2 & ";" & PrizeB3 & ";" &
ProbA1 & ";" & ProbA2 & ";" & ProbA3 & ";" & ProbB1 & ";" & ProbB2 & ";" & ProbB3 & ";" &
Endowment & ";" & qid & ";" & Mixed & ";" & Loss & ";" & LotSet & ";" & Pair & ";" & ChoiceA & ";" & ChoiceB & ";" &
        ImageN & ";" & ProbG & ";" & Points & ";" & pickedprob & ";" &
        period & ";" & choice1 & ";" & choice2 & ";" & realization & ";" &
        Question & ";" & answer & ";" &
        roll40 & ";" & roll100 & ";" & earnings
        sFile.WriteLine(line)
        sFile.Close()
    End Sub


    Private Function GetColor(ByVal itemIndex As Integer) As Color
        Dim objColor As Color
        Select Case itemIndex
            Case 0
                objColor = Color.LightBlue
            Case 1
                objColor = Color.LightGray
            Case 2
                objColor = Color.LightSalmon
            Case 3
                objColor = Color.Honeydew
            Case 4
                objColor = Color.Red
            Case 5
                objColor = Color.Green
            Case 6
                objColor = Color.Gray
            Case 7
                objColor = Color.Maroon
            Case Else
                objColor = Color.Green
        End Select
        Return objColor
    End Function

    Private Sub ChooseA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChooseA.Click
        Me.LotteryA.BorderStyle = BorderStyle.Fixed3D
        Me.LotteryB.BorderStyle = BorderStyle.None
        Me.Button1.Enabled = True
        Dim Task As Integer = sGetINI(sInfoFile, "RAtask", "Task", 0)
        writeINI(sResultsFile, "ChoiceL", Task, 1)
    End Sub

    Private Sub ChooseB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChooseB.Click
        Me.LotteryB.BorderStyle = BorderStyle.Fixed3D
        Me.LotteryA.BorderStyle = BorderStyle.None
        Me.Button1.Enabled = True
        Dim Task As Integer = sGetINI(sInfoFile, "RAtask", "Task", 0)
        writeINI(sResultsFile, "ChoiceL", Task, 2)


    End Sub

    Private Sub LotteryA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LotteryA.Click
        Me.LotteryA.BorderStyle = BorderStyle.Fixed3D
        Me.LotteryB.BorderStyle = BorderStyle.None
        Me.Button1.Enabled = True
        Me.ChooseA.Select()
        Dim Task As Integer = sGetINI(sInfoFile, "RAtask", "Task", "?")
        writeINI(sResultsFile, "ChoiceL", Task, 1)

    End Sub

    Private Sub LotteryB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LotteryB.Click
        Me.LotteryB.BorderStyle = BorderStyle.Fixed3D
        Me.LotteryA.BorderStyle = BorderStyle.None
        Me.Button1.Enabled = True
        Me.ChooseB.Select()
        Dim Task As Integer = sGetINI(sInfoFile, "RAtask", "Task", "?")
        writeINI(sResultsFile, "ChoiceL", Task, 2)

    End Sub

End Class
