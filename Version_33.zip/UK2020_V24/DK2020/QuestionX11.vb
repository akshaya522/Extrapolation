Public Class QuestionX11


    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Okbutton As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents NumericUpDown3 As NumericUpDown
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label20 As Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Okbutton = New System.Windows.Forms.Button()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Okbutton
        '
        Me.Okbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Okbutton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Okbutton.Location = New System.Drawing.Point(885, 489)
        Me.Okbutton.Name = "Okbutton"
        Me.Okbutton.Size = New System.Drawing.Size(102, 37)
        Me.Okbutton.TabIndex = 0
        Me.Okbutton.Text = "OK"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(252, 271)
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(54, 20)
        Me.NumericUpDown1.TabIndex = 21
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(255, 357)
        Me.NumericUpDown2.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(51, 20)
        Me.NumericUpDown2.TabIndex = 25
        Me.NumericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Location = New System.Drawing.Point(252, 455)
        Me.NumericUpDown3.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(54, 20)
        Me.NumericUpDown3.TabIndex = 30
        Me.NumericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(1006, 48)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "11. Dette sp�rgsm�l er som det sidste, men vi giver dig nu det historiske afkast " &
    "p� aktiemarkedet i Danmark" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(72, 70)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(848, 29)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "I de seneste to �r,  2018-2019, var det gennemsnitlige �rlige aktieafkast i Danma" &
    "rk 15 pct."
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(72, 99)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(848, 34)
        Me.Label17.TabIndex = 41
        Me.Label17.Text = "I de seneste fem �r, 2014-2019, var det gennemsnitlige �rlige aktieafkast i Danma" &
    "rk -5 pct."
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(72, 133)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(848, 29)
        Me.Label18.TabIndex = 42
        Me.Label18.Text = "I de seneste ti �r, 2009-2019, var det gennemsnitlige �rlige aktieafkast i Danmar" &
    "k 5 pct."
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(72, 162)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(848, 28)
        Me.Label19.TabIndex = 43
        Me.Label19.Text = "I de seneste tyve �r, 1999-2019, var det gennemsnitlige �rlige aktieafkast i Danm" &
    "ark 4 pct."
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(72, 190)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(848, 28)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "I de seneste halvtreds �r, 1969-2019, var det gennemsnitlige �rlige aktieafkast i" &
    " Danmark 3 pct."
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(46, 222)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(925, 48)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = "A.   Hvad forventer du at det gennemsnitlige �rlige afkast   p� OMX indeks er ove" &
    "r det n�ste �r (2020)?"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(418, 266)
        Me.Label13.Margin = New System.Windows.Forms.Padding(0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 24)
        Me.Label13.TabIndex = 47
        Me.Label13.Text = "n�ste �r"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label3.Location = New System.Drawing.Point(83, 266)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(332, 24)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "En stigning/fald p�             % over det "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(418, 353)
        Me.Label14.Margin = New System.Windows.Forms.Padding(0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(92, 24)
        Me.Label14.TabIndex = 49
        Me.Label14.Text = "n�ste 5 �r"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label6.Location = New System.Drawing.Point(83, 354)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(321, 24)
        Me.Label6.TabIndex = 50
        Me.Label6.Text = "En stigning/fald p�             % over de"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(46, 294)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(900, 48)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "B. Hvad forventer du at det gennemsnitlige �rlige afkast    p� OMX indeks er over" &
    " de n�ste 5 �r?"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(46, 390)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(900, 48)
        Me.Label12.TabIndex = 52
        Me.Label12.Text = "C. Hvad forventer du at det gennemsnitlige �rlige afkast    p� OMX indeks er over" &
    " de n�ste 10 �r?"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label7.Location = New System.Drawing.Point(83, 451)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(326, 24)
        Me.Label7.TabIndex = 55
        Me.Label7.Text = "En stigning/fald p�             % over de "
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(418, 451)
        Me.Label15.Margin = New System.Windows.Forms.Padding(0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(102, 24)
        Me.Label15.TabIndex = 54
        Me.Label15.Text = "n�ste 10 �r"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Garamond", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(309, 222)
        Me.Label9.Margin = New System.Windows.Forms.Padding(0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(267, 48)
        Me.Label9.TabIndex = 56
        Me.Label9.Text = "gennemsnitlige �rlige afkast"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Garamond", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(297, 294)
        Me.Label4.Margin = New System.Windows.Forms.Padding(0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(267, 48)
        Me.Label4.TabIndex = 57
        Me.Label4.Text = "gennemsnitlige �rlige afkast"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Garamond", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(297, 390)
        Me.Label8.Margin = New System.Windows.Forms.Padding(0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(267, 48)
        Me.Label8.TabIndex = 58
        Me.Label8.Text = "gennemsnitlige �rlige afkast"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(470, 491)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(0, 13)
        Me.Label10.TabIndex = 59
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(72, 41)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(848, 29)
        Me.Label11.TabIndex = 60
        Me.Label11.Text = "I det seneste �r, 2019, var det gennemsnitlige �rlige aktieafkast i Danmark 5 pct" &
    "."
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'QuestionX11
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1005, 545)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.NumericUpDown3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.NumericUpDown2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Okbutton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "QuestionX11"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                           "GetPrivateProfileStringA" (ByVal lpApplicationName _
                           As String, ByVal lpKeyName As String, ByVal lpDefault _
                           As String, ByVal lpReturnedString As String, ByVal _
                           nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub
    Public ChoiceA As Single = 0
    Public ChoiceB As Single = 0
    Public ChoiceC As Single = 0

    Private Sub Okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Okbutton.Click

        writeINI("../Quest.ini", "Sp�rgsm�l", "QX11_A", NumericUpDown1.Value)
        writeINI("../Quest.ini", "Sp�rgsm�l", "QX11_B", NumericUpDown2.Value)
        writeINI("../Quest.ini", "Sp�rgsm�l", "QX11_C", NumericUpDown3.Value)

        If ChoiceA = 0 Then
            MsgBox("Besvar venligst sp�rgsm�l A", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If
        If ChoiceB = 0 Then
            MsgBox("Besvar venligst sp�rgsm�l B", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If
        If ChoiceC = 0 Then
            MsgBox("Besvar venligst sp�rgsm�l C", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If

        Dim Forms As New QuestionX12()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()
    End Sub

    Private Sub LoadForm(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Okbutton.Enabled = False
        Select Case sGetINI("../Quest.ini", "Sp�rgsm�l", "QX11_A", "?")
            Case "?"
            Case Else
                NumericUpDown1.Value = sGetINI("../Quest.ini", "Sp�rgsm�l", "QX11_A", "?")
                NumericUpDown2.Value = sGetINI("../Quest.ini", "Sp�rgsm�l", "QX11_B", "?")
                NumericUpDown3.Value = sGetINI("../Quest.ini", "Sp�rgsm�l", "QX11_C", "?")
                Okbutton.Enabled = True
        End Select

    End Sub

    Private Sub TilbageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim Forms As New QuestionX10()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()


    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
        ChoiceA = 1
        If ChoiceA = 1 And ChoiceB = 1 And ChoiceC = 1 Then
            Me.Okbutton.Enabled = True
        End If
    End Sub

    Private Sub NumericUpDown2_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown2.ValueChanged
        ChoiceB = 1
        If ChoiceA = 1 And ChoiceB = 1 And ChoiceC = 1 Then
            Me.Okbutton.Enabled = True
        End If

    End Sub

    Private Sub NumericUpDown3_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown3.ValueChanged
        ChoiceC = 1
        If ChoiceA = 1 And ChoiceB = 1 And ChoiceC = 1 Then
            Me.Okbutton.Enabled = True
        End If
    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs) Handles Label17.Click

    End Sub
End Class
