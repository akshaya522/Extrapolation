
Imports System.Math
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Drawing.Graphics
Imports System.Windows.Forms.PaintEventArgs
Imports System.Threading



Public Class DK_ATTENTION_RESULTS2


    Inherits System.Windows.Forms.Form
    Private sInfoFile As String = "../tmpInfo.ini"
    Private sResultsFile As String = "../tmpResult.ini"
    Private sSetupFile As String = "../tmpSetup.ini"
    Private sEarningsFile As String = "../tmpEarnings.ini"
    Private sStageFile As String = "../tmpStage.ini"
    Friend WithEvents Infortext As System.Windows.Forms.Label
    Friend WithEvents Choose48 As System.Windows.Forms.Button
    Friend WithEvents IDlabel As System.Windows.Forms.Label
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents PictureBox17 As PictureBox
    Friend WithEvents PictureBox18 As PictureBox
    Friend WithEvents PictureBox19 As PictureBox
    Friend WithEvents PictureBox20 As PictureBox
    Friend WithEvents Choose49 As Button
    Friend WithEvents Choose50 As Button
    Friend WithEvents Choose51 As Button
    Friend WithEvents Choose52 As Button
    Friend WithEvents IfCorrect As Label
    Friend WithEvents PictureBox21 As PictureBox
    Friend WithEvents PictureBox22 As PictureBox
    Friend WithEvents PictureBox23 As PictureBox
    Friend WithEvents PictureBox24 As PictureBox
    Friend WithEvents PictureBox25 As PictureBox
    Friend WithEvents PictureBox26 As PictureBox
    Friend WithEvents PictureBox27 As PictureBox
    Friend WithEvents PictureBox28 As PictureBox
    Friend WithEvents PictureBox29 As PictureBox
    Friend WithEvents PictureBox30 As PictureBox
    Friend WithEvents PictureBox31 As PictureBox
    Friend WithEvents PictureBox32 As PictureBox
    Friend WithEvents PictureBox33 As PictureBox
    Friend WithEvents PictureBox34 As PictureBox
    Friend WithEvents PictureBox35 As PictureBox
    Friend WithEvents PictureBox36 As PictureBox
    Friend WithEvents PictureBox37 As PictureBox
    Friend WithEvents PictureBox38 As PictureBox
    Friend WithEvents PictureBox39 As PictureBox
    Friend WithEvents PictureBox40 As PictureBox
    Friend WithEvents PictureBox41 As PictureBox
    Friend WithEvents PictureBox42 As PictureBox
    Friend WithEvents PictureBox43 As PictureBox
    Friend WithEvents PictureBox44 As PictureBox
    Friend WithEvents PictureBox45 As PictureBox
    Friend WithEvents PictureBox46 As PictureBox
    Friend WithEvents PictureBox47 As PictureBox
    Friend WithEvents PictureBox48 As PictureBox
    Friend WithEvents PictureBox49 As PictureBox
    Friend WithEvents PictureBox50 As PictureBox
    Friend WithEvents PictureBox51 As PictureBox
    Friend WithEvents PictureBox52 As PictureBox
    Friend WithEvents PictureBox53 As PictureBox
    Friend WithEvents PictureBox54 As PictureBox
    Friend WithEvents PictureBox55 As PictureBox
    Friend WithEvents PictureBox56 As PictureBox
    Friend WithEvents PictureBox57 As PictureBox
    Friend WithEvents PictureBox58 As PictureBox
    Friend WithEvents PictureBox59 As PictureBox
    Friend WithEvents PictureBox60 As PictureBox
    Friend WithEvents PictureBox61 As PictureBox
    Friend WithEvents PictureBox62 As PictureBox
    Friend WithEvents PictureBox63 As PictureBox
    Friend WithEvents PictureBox64 As PictureBox
    Friend WithEvents PictureBox65 As PictureBox
    Friend WithEvents PictureBox66 As PictureBox
    Friend WithEvents PictureBox67 As PictureBox
    Friend WithEvents PictureBox68 As PictureBox
    Friend WithEvents PictureBox69 As PictureBox
    Friend WithEvents PictureBox70 As PictureBox
    Friend WithEvents PictureBox71 As PictureBox
    Friend WithEvents PictureBox72 As PictureBox
    Friend WithEvents PictureBox73 As PictureBox
    Friend WithEvents PictureBox74 As PictureBox
    Friend WithEvents PictureBox75 As PictureBox
    Friend WithEvents PictureBox76 As PictureBox
    Friend WithEvents PictureBox77 As PictureBox
    Friend WithEvents PictureBox78 As PictureBox
    Friend WithEvents PictureBox79 As PictureBox
    Friend WithEvents PictureBox80 As PictureBox
    Friend WithEvents PictureBox81 As PictureBox
    Friend WithEvents PictureBox82 As PictureBox
    Friend WithEvents PictureBox83 As PictureBox
    Friend WithEvents PictureBox84 As PictureBox
    Friend WithEvents PictureBox85 As PictureBox
    Friend WithEvents PictureBox86 As PictureBox
    Friend WithEvents PictureBox87 As PictureBox
    Friend WithEvents PictureBox88 As PictureBox
    Friend WithEvents PictureBox89 As PictureBox
    Friend WithEvents PictureBox90 As PictureBox
    Friend WithEvents PictureBox91 As PictureBox
    Friend WithEvents PictureBox92 As PictureBox
    Friend WithEvents PictureBox93 As PictureBox
    Friend WithEvents PictureBox94 As PictureBox
    Friend WithEvents PictureBox95 As PictureBox
    Friend WithEvents PictureBox96 As PictureBox
    Friend WithEvents PictureBox97 As PictureBox
    Friend WithEvents PictureBox98 As PictureBox
    Friend WithEvents PictureBox99 As PictureBox
    Friend WithEvents PictureBox100 As PictureBox
    Friend WithEvents PictureBox101 As PictureBox
    Friend WithEvents PictureBox102 As PictureBox
    Friend WithEvents PictureBox103 As PictureBox
    Friend WithEvents PictureBox104 As PictureBox
    Friend WithEvents PictureBox105 As PictureBox
    Friend WithEvents PictureBox106 As PictureBox
    Friend WithEvents PictureBox107 As PictureBox
    Friend WithEvents PictureBox108 As PictureBox
    Friend WithEvents PictureBox109 As PictureBox
    Friend WithEvents PictureBox110 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents NumericUpDown4 As NumericUpDown
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents Label3 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label4 As Label
    Dim brushes(5) As System.Drawing.SolidBrush



#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Friend WithEvents Header As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Header = New System.Windows.Forms.Label()
        Me.Infortext = New System.Windows.Forms.Label()
        Me.Choose48 = New System.Windows.Forms.Button()
        Me.IDlabel = New System.Windows.Forms.Label()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.Choose49 = New System.Windows.Forms.Button()
        Me.Choose50 = New System.Windows.Forms.Button()
        Me.Choose51 = New System.Windows.Forms.Button()
        Me.Choose52 = New System.Windows.Forms.Button()
        Me.IfCorrect = New System.Windows.Forms.Label()
        Me.PictureBox21 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.PictureBox25 = New System.Windows.Forms.PictureBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.PictureBox27 = New System.Windows.Forms.PictureBox()
        Me.PictureBox28 = New System.Windows.Forms.PictureBox()
        Me.PictureBox29 = New System.Windows.Forms.PictureBox()
        Me.PictureBox30 = New System.Windows.Forms.PictureBox()
        Me.PictureBox31 = New System.Windows.Forms.PictureBox()
        Me.PictureBox32 = New System.Windows.Forms.PictureBox()
        Me.PictureBox33 = New System.Windows.Forms.PictureBox()
        Me.PictureBox34 = New System.Windows.Forms.PictureBox()
        Me.PictureBox35 = New System.Windows.Forms.PictureBox()
        Me.PictureBox36 = New System.Windows.Forms.PictureBox()
        Me.PictureBox37 = New System.Windows.Forms.PictureBox()
        Me.PictureBox38 = New System.Windows.Forms.PictureBox()
        Me.PictureBox39 = New System.Windows.Forms.PictureBox()
        Me.PictureBox40 = New System.Windows.Forms.PictureBox()
        Me.PictureBox41 = New System.Windows.Forms.PictureBox()
        Me.PictureBox42 = New System.Windows.Forms.PictureBox()
        Me.PictureBox43 = New System.Windows.Forms.PictureBox()
        Me.PictureBox44 = New System.Windows.Forms.PictureBox()
        Me.PictureBox45 = New System.Windows.Forms.PictureBox()
        Me.PictureBox46 = New System.Windows.Forms.PictureBox()
        Me.PictureBox47 = New System.Windows.Forms.PictureBox()
        Me.PictureBox48 = New System.Windows.Forms.PictureBox()
        Me.PictureBox49 = New System.Windows.Forms.PictureBox()
        Me.PictureBox50 = New System.Windows.Forms.PictureBox()
        Me.PictureBox51 = New System.Windows.Forms.PictureBox()
        Me.PictureBox52 = New System.Windows.Forms.PictureBox()
        Me.PictureBox53 = New System.Windows.Forms.PictureBox()
        Me.PictureBox54 = New System.Windows.Forms.PictureBox()
        Me.PictureBox55 = New System.Windows.Forms.PictureBox()
        Me.PictureBox56 = New System.Windows.Forms.PictureBox()
        Me.PictureBox57 = New System.Windows.Forms.PictureBox()
        Me.PictureBox58 = New System.Windows.Forms.PictureBox()
        Me.PictureBox59 = New System.Windows.Forms.PictureBox()
        Me.PictureBox60 = New System.Windows.Forms.PictureBox()
        Me.PictureBox61 = New System.Windows.Forms.PictureBox()
        Me.PictureBox62 = New System.Windows.Forms.PictureBox()
        Me.PictureBox63 = New System.Windows.Forms.PictureBox()
        Me.PictureBox64 = New System.Windows.Forms.PictureBox()
        Me.PictureBox65 = New System.Windows.Forms.PictureBox()
        Me.PictureBox66 = New System.Windows.Forms.PictureBox()
        Me.PictureBox67 = New System.Windows.Forms.PictureBox()
        Me.PictureBox68 = New System.Windows.Forms.PictureBox()
        Me.PictureBox69 = New System.Windows.Forms.PictureBox()
        Me.PictureBox70 = New System.Windows.Forms.PictureBox()
        Me.PictureBox71 = New System.Windows.Forms.PictureBox()
        Me.PictureBox72 = New System.Windows.Forms.PictureBox()
        Me.PictureBox73 = New System.Windows.Forms.PictureBox()
        Me.PictureBox74 = New System.Windows.Forms.PictureBox()
        Me.PictureBox75 = New System.Windows.Forms.PictureBox()
        Me.PictureBox76 = New System.Windows.Forms.PictureBox()
        Me.PictureBox77 = New System.Windows.Forms.PictureBox()
        Me.PictureBox78 = New System.Windows.Forms.PictureBox()
        Me.PictureBox79 = New System.Windows.Forms.PictureBox()
        Me.PictureBox80 = New System.Windows.Forms.PictureBox()
        Me.PictureBox81 = New System.Windows.Forms.PictureBox()
        Me.PictureBox82 = New System.Windows.Forms.PictureBox()
        Me.PictureBox83 = New System.Windows.Forms.PictureBox()
        Me.PictureBox84 = New System.Windows.Forms.PictureBox()
        Me.PictureBox85 = New System.Windows.Forms.PictureBox()
        Me.PictureBox86 = New System.Windows.Forms.PictureBox()
        Me.PictureBox87 = New System.Windows.Forms.PictureBox()
        Me.PictureBox88 = New System.Windows.Forms.PictureBox()
        Me.PictureBox89 = New System.Windows.Forms.PictureBox()
        Me.PictureBox90 = New System.Windows.Forms.PictureBox()
        Me.PictureBox91 = New System.Windows.Forms.PictureBox()
        Me.PictureBox92 = New System.Windows.Forms.PictureBox()
        Me.PictureBox93 = New System.Windows.Forms.PictureBox()
        Me.PictureBox94 = New System.Windows.Forms.PictureBox()
        Me.PictureBox95 = New System.Windows.Forms.PictureBox()
        Me.PictureBox96 = New System.Windows.Forms.PictureBox()
        Me.PictureBox97 = New System.Windows.Forms.PictureBox()
        Me.PictureBox98 = New System.Windows.Forms.PictureBox()
        Me.PictureBox99 = New System.Windows.Forms.PictureBox()
        Me.PictureBox100 = New System.Windows.Forms.PictureBox()
        Me.PictureBox101 = New System.Windows.Forms.PictureBox()
        Me.PictureBox102 = New System.Windows.Forms.PictureBox()
        Me.PictureBox103 = New System.Windows.Forms.PictureBox()
        Me.PictureBox104 = New System.Windows.Forms.PictureBox()
        Me.PictureBox105 = New System.Windows.Forms.PictureBox()
        Me.PictureBox106 = New System.Windows.Forms.PictureBox()
        Me.PictureBox107 = New System.Windows.Forms.PictureBox()
        Me.PictureBox108 = New System.Windows.Forms.PictureBox()
        Me.PictureBox109 = New System.Windows.Forms.PictureBox()
        Me.PictureBox110 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Header
        '
        Me.Header.Font = New System.Drawing.Font("Garamond", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header.Location = New System.Drawing.Point(8, 3)
        Me.Header.Name = "Header"
        Me.Header.Size = New System.Drawing.Size(461, 48)
        Me.Header.TabIndex = 16
        Me.Header.Text = "testing"
        Me.Header.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Infortext
        '
        Me.Infortext.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Infortext.Location = New System.Drawing.Point(13, 407)
        Me.Infortext.Name = "Infortext"
        Me.Infortext.Size = New System.Drawing.Size(610, 28)
        Me.Infortext.TabIndex = 47
        Me.Infortext.Text = "Lottery Valgmulighed A"
        Me.Infortext.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Infortext.Visible = False
        '
        'Choose48
        '
        Me.Choose48.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Choose48.Location = New System.Drawing.Point(17, 438)
        Me.Choose48.Name = "Choose48"
        Me.Choose48.Size = New System.Drawing.Size(95, 63)
        Me.Choose48.TabIndex = 49
        Me.Choose48.Text = "48"
        Me.Choose48.UseVisualStyleBackColor = True
        '
        'IDlabel
        '
        Me.IDlabel.AutoSize = True
        Me.IDlabel.Font = New System.Drawing.Font("Garamond", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IDlabel.Location = New System.Drawing.Point(585, 17)
        Me.IDlabel.Name = "IDlabel"
        Me.IDlabel.Size = New System.Drawing.Size(60, 18)
        Me.IDlabel.TabIndex = 54
        Me.IDlabel.Text = "IDlabel"
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox11.Location = New System.Drawing.Point(400, 125)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox11.TabIndex = 74
        Me.PictureBox11.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox12.Location = New System.Drawing.Point(375, 125)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox12.TabIndex = 73
        Me.PictureBox12.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox13.Location = New System.Drawing.Point(350, 125)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox13.TabIndex = 72
        Me.PictureBox13.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox14.Location = New System.Drawing.Point(325, 125)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox14.TabIndex = 71
        Me.PictureBox14.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox15.Location = New System.Drawing.Point(300, 125)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox15.TabIndex = 70
        Me.PictureBox15.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox16.Location = New System.Drawing.Point(275, 125)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox16.TabIndex = 69
        Me.PictureBox16.TabStop = False
        '
        'PictureBox17
        '
        Me.PictureBox17.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox17.Location = New System.Drawing.Point(250, 125)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox17.TabIndex = 68
        Me.PictureBox17.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox18.Location = New System.Drawing.Point(225, 125)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox18.TabIndex = 67
        Me.PictureBox18.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox19.Location = New System.Drawing.Point(200, 125)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox19.TabIndex = 66
        Me.PictureBox19.TabStop = False
        '
        'PictureBox20
        '
        Me.PictureBox20.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox20.Location = New System.Drawing.Point(175, 125)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox20.TabIndex = 65
        Me.PictureBox20.TabStop = False
        '
        'Choose49
        '
        Me.Choose49.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Choose49.Location = New System.Drawing.Point(142, 438)
        Me.Choose49.Name = "Choose49"
        Me.Choose49.Size = New System.Drawing.Size(95, 63)
        Me.Choose49.TabIndex = 165
        Me.Choose49.Text = "49"
        Me.Choose49.UseVisualStyleBackColor = True
        '
        'Choose50
        '
        Me.Choose50.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Choose50.Location = New System.Drawing.Point(267, 438)
        Me.Choose50.Name = "Choose50"
        Me.Choose50.Size = New System.Drawing.Size(95, 63)
        Me.Choose50.TabIndex = 166
        Me.Choose50.Text = "50"
        Me.Choose50.UseVisualStyleBackColor = True
        '
        'Choose51
        '
        Me.Choose51.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Choose51.Location = New System.Drawing.Point(395, 438)
        Me.Choose51.Name = "Choose51"
        Me.Choose51.Size = New System.Drawing.Size(95, 63)
        Me.Choose51.TabIndex = 167
        Me.Choose51.Text = "51"
        Me.Choose51.UseVisualStyleBackColor = True
        '
        'Choose52
        '
        Me.Choose52.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Choose52.Location = New System.Drawing.Point(528, 438)
        Me.Choose52.Name = "Choose52"
        Me.Choose52.Size = New System.Drawing.Size(95, 63)
        Me.Choose52.TabIndex = 168
        Me.Choose52.Text = "52"
        Me.Choose52.UseVisualStyleBackColor = True
        '
        'IfCorrect
        '
        Me.IfCorrect.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IfCorrect.Location = New System.Drawing.Point(10, 60)
        Me.IfCorrect.Name = "IfCorrect"
        Me.IfCorrect.Size = New System.Drawing.Size(265, 41)
        Me.IfCorrect.TabIndex = 169
        Me.IfCorrect.Text = "If correct"
        Me.IfCorrect.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.IfCorrect.Visible = False
        '
        'PictureBox21
        '
        Me.PictureBox21.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox21.Location = New System.Drawing.Point(400, 150)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox21.TabIndex = 190
        Me.PictureBox21.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox22.Location = New System.Drawing.Point(375, 150)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox22.TabIndex = 189
        Me.PictureBox22.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox23.Location = New System.Drawing.Point(350, 150)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox23.TabIndex = 188
        Me.PictureBox23.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox24.Location = New System.Drawing.Point(325, 150)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox24.TabIndex = 187
        Me.PictureBox24.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox25.Location = New System.Drawing.Point(300, 150)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox25.TabIndex = 186
        Me.PictureBox25.TabStop = False
        '
        'PictureBox26
        '
        Me.PictureBox26.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox26.Location = New System.Drawing.Point(275, 150)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox26.TabIndex = 185
        Me.PictureBox26.TabStop = False
        '
        'PictureBox27
        '
        Me.PictureBox27.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox27.Location = New System.Drawing.Point(250, 150)
        Me.PictureBox27.Name = "PictureBox27"
        Me.PictureBox27.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox27.TabIndex = 184
        Me.PictureBox27.TabStop = False
        '
        'PictureBox28
        '
        Me.PictureBox28.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox28.Location = New System.Drawing.Point(225, 150)
        Me.PictureBox28.Name = "PictureBox28"
        Me.PictureBox28.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox28.TabIndex = 183
        Me.PictureBox28.TabStop = False
        '
        'PictureBox29
        '
        Me.PictureBox29.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox29.Location = New System.Drawing.Point(200, 150)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox29.TabIndex = 182
        Me.PictureBox29.TabStop = False
        '
        'PictureBox30
        '
        Me.PictureBox30.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox30.Location = New System.Drawing.Point(175, 150)
        Me.PictureBox30.Name = "PictureBox30"
        Me.PictureBox30.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox30.TabIndex = 181
        Me.PictureBox30.TabStop = False
        '
        'PictureBox31
        '
        Me.PictureBox31.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox31.Location = New System.Drawing.Point(400, 175)
        Me.PictureBox31.Name = "PictureBox31"
        Me.PictureBox31.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox31.TabIndex = 200
        Me.PictureBox31.TabStop = False
        '
        'PictureBox32
        '
        Me.PictureBox32.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox32.Location = New System.Drawing.Point(375, 175)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox32.TabIndex = 199
        Me.PictureBox32.TabStop = False
        '
        'PictureBox33
        '
        Me.PictureBox33.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox33.Location = New System.Drawing.Point(350, 175)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox33.TabIndex = 198
        Me.PictureBox33.TabStop = False
        '
        'PictureBox34
        '
        Me.PictureBox34.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox34.Location = New System.Drawing.Point(325, 175)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox34.TabIndex = 197
        Me.PictureBox34.TabStop = False
        '
        'PictureBox35
        '
        Me.PictureBox35.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox35.Location = New System.Drawing.Point(300, 175)
        Me.PictureBox35.Name = "PictureBox35"
        Me.PictureBox35.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox35.TabIndex = 196
        Me.PictureBox35.TabStop = False
        '
        'PictureBox36
        '
        Me.PictureBox36.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox36.Location = New System.Drawing.Point(275, 175)
        Me.PictureBox36.Name = "PictureBox36"
        Me.PictureBox36.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox36.TabIndex = 195
        Me.PictureBox36.TabStop = False
        '
        'PictureBox37
        '
        Me.PictureBox37.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox37.Location = New System.Drawing.Point(250, 175)
        Me.PictureBox37.Name = "PictureBox37"
        Me.PictureBox37.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox37.TabIndex = 194
        Me.PictureBox37.TabStop = False
        '
        'PictureBox38
        '
        Me.PictureBox38.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox38.Location = New System.Drawing.Point(225, 175)
        Me.PictureBox38.Name = "PictureBox38"
        Me.PictureBox38.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox38.TabIndex = 193
        Me.PictureBox38.TabStop = False
        '
        'PictureBox39
        '
        Me.PictureBox39.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox39.Location = New System.Drawing.Point(200, 175)
        Me.PictureBox39.Name = "PictureBox39"
        Me.PictureBox39.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox39.TabIndex = 192
        Me.PictureBox39.TabStop = False
        '
        'PictureBox40
        '
        Me.PictureBox40.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox40.Location = New System.Drawing.Point(175, 175)
        Me.PictureBox40.Name = "PictureBox40"
        Me.PictureBox40.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox40.TabIndex = 191
        Me.PictureBox40.TabStop = False
        '
        'PictureBox41
        '
        Me.PictureBox41.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox41.Location = New System.Drawing.Point(400, 200)
        Me.PictureBox41.Name = "PictureBox41"
        Me.PictureBox41.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox41.TabIndex = 210
        Me.PictureBox41.TabStop = False
        '
        'PictureBox42
        '
        Me.PictureBox42.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox42.Location = New System.Drawing.Point(375, 200)
        Me.PictureBox42.Name = "PictureBox42"
        Me.PictureBox42.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox42.TabIndex = 209
        Me.PictureBox42.TabStop = False
        '
        'PictureBox43
        '
        Me.PictureBox43.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox43.Location = New System.Drawing.Point(350, 200)
        Me.PictureBox43.Name = "PictureBox43"
        Me.PictureBox43.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox43.TabIndex = 208
        Me.PictureBox43.TabStop = False
        '
        'PictureBox44
        '
        Me.PictureBox44.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox44.Location = New System.Drawing.Point(325, 200)
        Me.PictureBox44.Name = "PictureBox44"
        Me.PictureBox44.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox44.TabIndex = 207
        Me.PictureBox44.TabStop = False
        '
        'PictureBox45
        '
        Me.PictureBox45.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox45.Location = New System.Drawing.Point(300, 200)
        Me.PictureBox45.Name = "PictureBox45"
        Me.PictureBox45.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox45.TabIndex = 206
        Me.PictureBox45.TabStop = False
        '
        'PictureBox46
        '
        Me.PictureBox46.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox46.Location = New System.Drawing.Point(275, 200)
        Me.PictureBox46.Name = "PictureBox46"
        Me.PictureBox46.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox46.TabIndex = 205
        Me.PictureBox46.TabStop = False
        '
        'PictureBox47
        '
        Me.PictureBox47.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox47.Location = New System.Drawing.Point(250, 200)
        Me.PictureBox47.Name = "PictureBox47"
        Me.PictureBox47.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox47.TabIndex = 204
        Me.PictureBox47.TabStop = False
        '
        'PictureBox48
        '
        Me.PictureBox48.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox48.Location = New System.Drawing.Point(225, 200)
        Me.PictureBox48.Name = "PictureBox48"
        Me.PictureBox48.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox48.TabIndex = 203
        Me.PictureBox48.TabStop = False
        '
        'PictureBox49
        '
        Me.PictureBox49.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox49.Location = New System.Drawing.Point(200, 200)
        Me.PictureBox49.Name = "PictureBox49"
        Me.PictureBox49.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox49.TabIndex = 202
        Me.PictureBox49.TabStop = False
        '
        'PictureBox50
        '
        Me.PictureBox50.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox50.Location = New System.Drawing.Point(175, 200)
        Me.PictureBox50.Name = "PictureBox50"
        Me.PictureBox50.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox50.TabIndex = 201
        Me.PictureBox50.TabStop = False
        '
        'PictureBox51
        '
        Me.PictureBox51.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox51.Location = New System.Drawing.Point(400, 225)
        Me.PictureBox51.Name = "PictureBox51"
        Me.PictureBox51.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox51.TabIndex = 220
        Me.PictureBox51.TabStop = False
        '
        'PictureBox52
        '
        Me.PictureBox52.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox52.Location = New System.Drawing.Point(375, 225)
        Me.PictureBox52.Name = "PictureBox52"
        Me.PictureBox52.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox52.TabIndex = 219
        Me.PictureBox52.TabStop = False
        '
        'PictureBox53
        '
        Me.PictureBox53.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox53.Location = New System.Drawing.Point(350, 225)
        Me.PictureBox53.Name = "PictureBox53"
        Me.PictureBox53.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox53.TabIndex = 218
        Me.PictureBox53.TabStop = False
        '
        'PictureBox54
        '
        Me.PictureBox54.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox54.Location = New System.Drawing.Point(325, 225)
        Me.PictureBox54.Name = "PictureBox54"
        Me.PictureBox54.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox54.TabIndex = 217
        Me.PictureBox54.TabStop = False
        '
        'PictureBox55
        '
        Me.PictureBox55.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox55.Location = New System.Drawing.Point(300, 225)
        Me.PictureBox55.Name = "PictureBox55"
        Me.PictureBox55.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox55.TabIndex = 216
        Me.PictureBox55.TabStop = False
        '
        'PictureBox56
        '
        Me.PictureBox56.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox56.Location = New System.Drawing.Point(275, 225)
        Me.PictureBox56.Name = "PictureBox56"
        Me.PictureBox56.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox56.TabIndex = 215
        Me.PictureBox56.TabStop = False
        '
        'PictureBox57
        '
        Me.PictureBox57.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox57.Location = New System.Drawing.Point(250, 225)
        Me.PictureBox57.Name = "PictureBox57"
        Me.PictureBox57.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox57.TabIndex = 214
        Me.PictureBox57.TabStop = False
        '
        'PictureBox58
        '
        Me.PictureBox58.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox58.Location = New System.Drawing.Point(225, 225)
        Me.PictureBox58.Name = "PictureBox58"
        Me.PictureBox58.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox58.TabIndex = 213
        Me.PictureBox58.TabStop = False
        '
        'PictureBox59
        '
        Me.PictureBox59.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox59.Location = New System.Drawing.Point(200, 225)
        Me.PictureBox59.Name = "PictureBox59"
        Me.PictureBox59.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox59.TabIndex = 212
        Me.PictureBox59.TabStop = False
        '
        'PictureBox60
        '
        Me.PictureBox60.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox60.Location = New System.Drawing.Point(175, 225)
        Me.PictureBox60.Name = "PictureBox60"
        Me.PictureBox60.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox60.TabIndex = 211
        Me.PictureBox60.TabStop = False
        '
        'PictureBox61
        '
        Me.PictureBox61.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox61.Location = New System.Drawing.Point(400, 250)
        Me.PictureBox61.Name = "PictureBox61"
        Me.PictureBox61.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox61.TabIndex = 230
        Me.PictureBox61.TabStop = False
        '
        'PictureBox62
        '
        Me.PictureBox62.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox62.Location = New System.Drawing.Point(375, 250)
        Me.PictureBox62.Name = "PictureBox62"
        Me.PictureBox62.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox62.TabIndex = 229
        Me.PictureBox62.TabStop = False
        '
        'PictureBox63
        '
        Me.PictureBox63.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox63.Location = New System.Drawing.Point(350, 250)
        Me.PictureBox63.Name = "PictureBox63"
        Me.PictureBox63.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox63.TabIndex = 228
        Me.PictureBox63.TabStop = False
        '
        'PictureBox64
        '
        Me.PictureBox64.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox64.Location = New System.Drawing.Point(325, 250)
        Me.PictureBox64.Name = "PictureBox64"
        Me.PictureBox64.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox64.TabIndex = 227
        Me.PictureBox64.TabStop = False
        '
        'PictureBox65
        '
        Me.PictureBox65.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox65.Location = New System.Drawing.Point(300, 250)
        Me.PictureBox65.Name = "PictureBox65"
        Me.PictureBox65.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox65.TabIndex = 226
        Me.PictureBox65.TabStop = False
        '
        'PictureBox66
        '
        Me.PictureBox66.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox66.Location = New System.Drawing.Point(275, 250)
        Me.PictureBox66.Name = "PictureBox66"
        Me.PictureBox66.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox66.TabIndex = 225
        Me.PictureBox66.TabStop = False
        '
        'PictureBox67
        '
        Me.PictureBox67.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox67.Location = New System.Drawing.Point(250, 250)
        Me.PictureBox67.Name = "PictureBox67"
        Me.PictureBox67.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox67.TabIndex = 224
        Me.PictureBox67.TabStop = False
        '
        'PictureBox68
        '
        Me.PictureBox68.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox68.Location = New System.Drawing.Point(225, 250)
        Me.PictureBox68.Name = "PictureBox68"
        Me.PictureBox68.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox68.TabIndex = 223
        Me.PictureBox68.TabStop = False
        '
        'PictureBox69
        '
        Me.PictureBox69.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox69.Location = New System.Drawing.Point(200, 250)
        Me.PictureBox69.Name = "PictureBox69"
        Me.PictureBox69.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox69.TabIndex = 222
        Me.PictureBox69.TabStop = False
        '
        'PictureBox70
        '
        Me.PictureBox70.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox70.Location = New System.Drawing.Point(175, 250)
        Me.PictureBox70.Name = "PictureBox70"
        Me.PictureBox70.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox70.TabIndex = 221
        Me.PictureBox70.TabStop = False
        '
        'PictureBox71
        '
        Me.PictureBox71.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox71.Location = New System.Drawing.Point(400, 275)
        Me.PictureBox71.Name = "PictureBox71"
        Me.PictureBox71.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox71.TabIndex = 240
        Me.PictureBox71.TabStop = False
        '
        'PictureBox72
        '
        Me.PictureBox72.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox72.Location = New System.Drawing.Point(375, 275)
        Me.PictureBox72.Name = "PictureBox72"
        Me.PictureBox72.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox72.TabIndex = 239
        Me.PictureBox72.TabStop = False
        '
        'PictureBox73
        '
        Me.PictureBox73.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox73.Location = New System.Drawing.Point(350, 275)
        Me.PictureBox73.Name = "PictureBox73"
        Me.PictureBox73.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox73.TabIndex = 238
        Me.PictureBox73.TabStop = False
        '
        'PictureBox74
        '
        Me.PictureBox74.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox74.Location = New System.Drawing.Point(325, 275)
        Me.PictureBox74.Name = "PictureBox74"
        Me.PictureBox74.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox74.TabIndex = 237
        Me.PictureBox74.TabStop = False
        '
        'PictureBox75
        '
        Me.PictureBox75.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox75.Location = New System.Drawing.Point(300, 275)
        Me.PictureBox75.Name = "PictureBox75"
        Me.PictureBox75.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox75.TabIndex = 236
        Me.PictureBox75.TabStop = False
        '
        'PictureBox76
        '
        Me.PictureBox76.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox76.Location = New System.Drawing.Point(275, 275)
        Me.PictureBox76.Name = "PictureBox76"
        Me.PictureBox76.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox76.TabIndex = 235
        Me.PictureBox76.TabStop = False
        '
        'PictureBox77
        '
        Me.PictureBox77.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox77.Location = New System.Drawing.Point(250, 275)
        Me.PictureBox77.Name = "PictureBox77"
        Me.PictureBox77.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox77.TabIndex = 234
        Me.PictureBox77.TabStop = False
        '
        'PictureBox78
        '
        Me.PictureBox78.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox78.Location = New System.Drawing.Point(225, 275)
        Me.PictureBox78.Name = "PictureBox78"
        Me.PictureBox78.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox78.TabIndex = 233
        Me.PictureBox78.TabStop = False
        '
        'PictureBox79
        '
        Me.PictureBox79.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox79.Location = New System.Drawing.Point(200, 275)
        Me.PictureBox79.Name = "PictureBox79"
        Me.PictureBox79.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox79.TabIndex = 232
        Me.PictureBox79.TabStop = False
        '
        'PictureBox80
        '
        Me.PictureBox80.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox80.Location = New System.Drawing.Point(175, 275)
        Me.PictureBox80.Name = "PictureBox80"
        Me.PictureBox80.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox80.TabIndex = 231
        Me.PictureBox80.TabStop = False
        '
        'PictureBox81
        '
        Me.PictureBox81.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox81.Location = New System.Drawing.Point(400, 300)
        Me.PictureBox81.Name = "PictureBox81"
        Me.PictureBox81.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox81.TabIndex = 250
        Me.PictureBox81.TabStop = False
        '
        'PictureBox82
        '
        Me.PictureBox82.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox82.Location = New System.Drawing.Point(375, 300)
        Me.PictureBox82.Name = "PictureBox82"
        Me.PictureBox82.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox82.TabIndex = 249
        Me.PictureBox82.TabStop = False
        '
        'PictureBox83
        '
        Me.PictureBox83.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox83.Location = New System.Drawing.Point(350, 300)
        Me.PictureBox83.Name = "PictureBox83"
        Me.PictureBox83.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox83.TabIndex = 248
        Me.PictureBox83.TabStop = False
        '
        'PictureBox84
        '
        Me.PictureBox84.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox84.Location = New System.Drawing.Point(325, 300)
        Me.PictureBox84.Name = "PictureBox84"
        Me.PictureBox84.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox84.TabIndex = 247
        Me.PictureBox84.TabStop = False
        '
        'PictureBox85
        '
        Me.PictureBox85.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox85.Location = New System.Drawing.Point(300, 300)
        Me.PictureBox85.Name = "PictureBox85"
        Me.PictureBox85.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox85.TabIndex = 246
        Me.PictureBox85.TabStop = False
        '
        'PictureBox86
        '
        Me.PictureBox86.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox86.Location = New System.Drawing.Point(275, 300)
        Me.PictureBox86.Name = "PictureBox86"
        Me.PictureBox86.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox86.TabIndex = 245
        Me.PictureBox86.TabStop = False
        '
        'PictureBox87
        '
        Me.PictureBox87.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox87.Location = New System.Drawing.Point(250, 300)
        Me.PictureBox87.Name = "PictureBox87"
        Me.PictureBox87.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox87.TabIndex = 244
        Me.PictureBox87.TabStop = False
        '
        'PictureBox88
        '
        Me.PictureBox88.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox88.Location = New System.Drawing.Point(225, 300)
        Me.PictureBox88.Name = "PictureBox88"
        Me.PictureBox88.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox88.TabIndex = 243
        Me.PictureBox88.TabStop = False
        '
        'PictureBox89
        '
        Me.PictureBox89.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox89.Location = New System.Drawing.Point(200, 300)
        Me.PictureBox89.Name = "PictureBox89"
        Me.PictureBox89.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox89.TabIndex = 242
        Me.PictureBox89.TabStop = False
        '
        'PictureBox90
        '
        Me.PictureBox90.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox90.Location = New System.Drawing.Point(175, 300)
        Me.PictureBox90.Name = "PictureBox90"
        Me.PictureBox90.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox90.TabIndex = 241
        Me.PictureBox90.TabStop = False
        '
        'PictureBox91
        '
        Me.PictureBox91.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox91.Location = New System.Drawing.Point(400, 325)
        Me.PictureBox91.Name = "PictureBox91"
        Me.PictureBox91.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox91.TabIndex = 260
        Me.PictureBox91.TabStop = False
        '
        'PictureBox92
        '
        Me.PictureBox92.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox92.Location = New System.Drawing.Point(375, 325)
        Me.PictureBox92.Name = "PictureBox92"
        Me.PictureBox92.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox92.TabIndex = 259
        Me.PictureBox92.TabStop = False
        '
        'PictureBox93
        '
        Me.PictureBox93.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox93.Location = New System.Drawing.Point(350, 325)
        Me.PictureBox93.Name = "PictureBox93"
        Me.PictureBox93.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox93.TabIndex = 258
        Me.PictureBox93.TabStop = False
        '
        'PictureBox94
        '
        Me.PictureBox94.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox94.Location = New System.Drawing.Point(325, 325)
        Me.PictureBox94.Name = "PictureBox94"
        Me.PictureBox94.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox94.TabIndex = 257
        Me.PictureBox94.TabStop = False
        '
        'PictureBox95
        '
        Me.PictureBox95.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox95.Location = New System.Drawing.Point(300, 325)
        Me.PictureBox95.Name = "PictureBox95"
        Me.PictureBox95.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox95.TabIndex = 256
        Me.PictureBox95.TabStop = False
        '
        'PictureBox96
        '
        Me.PictureBox96.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox96.Location = New System.Drawing.Point(275, 325)
        Me.PictureBox96.Name = "PictureBox96"
        Me.PictureBox96.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox96.TabIndex = 255
        Me.PictureBox96.TabStop = False
        '
        'PictureBox97
        '
        Me.PictureBox97.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox97.Location = New System.Drawing.Point(250, 325)
        Me.PictureBox97.Name = "PictureBox97"
        Me.PictureBox97.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox97.TabIndex = 254
        Me.PictureBox97.TabStop = False
        '
        'PictureBox98
        '
        Me.PictureBox98.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox98.Location = New System.Drawing.Point(225, 325)
        Me.PictureBox98.Name = "PictureBox98"
        Me.PictureBox98.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox98.TabIndex = 253
        Me.PictureBox98.TabStop = False
        '
        'PictureBox99
        '
        Me.PictureBox99.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox99.Location = New System.Drawing.Point(200, 325)
        Me.PictureBox99.Name = "PictureBox99"
        Me.PictureBox99.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox99.TabIndex = 252
        Me.PictureBox99.TabStop = False
        '
        'PictureBox100
        '
        Me.PictureBox100.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox100.Location = New System.Drawing.Point(175, 325)
        Me.PictureBox100.Name = "PictureBox100"
        Me.PictureBox100.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox100.TabIndex = 251
        Me.PictureBox100.TabStop = False
        '
        'PictureBox101
        '
        Me.PictureBox101.Image = Global.DK2020.My.Resources.Resources.circleB
        Me.PictureBox101.Location = New System.Drawing.Point(400, 350)
        Me.PictureBox101.Name = "PictureBox101"
        Me.PictureBox101.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox101.TabIndex = 270
        Me.PictureBox101.TabStop = False
        '
        'PictureBox102
        '
        Me.PictureBox102.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox102.Location = New System.Drawing.Point(375, 350)
        Me.PictureBox102.Name = "PictureBox102"
        Me.PictureBox102.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox102.TabIndex = 269
        Me.PictureBox102.TabStop = False
        '
        'PictureBox103
        '
        Me.PictureBox103.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox103.Location = New System.Drawing.Point(350, 350)
        Me.PictureBox103.Name = "PictureBox103"
        Me.PictureBox103.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox103.TabIndex = 268
        Me.PictureBox103.TabStop = False
        '
        'PictureBox104
        '
        Me.PictureBox104.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox104.Location = New System.Drawing.Point(325, 350)
        Me.PictureBox104.Name = "PictureBox104"
        Me.PictureBox104.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox104.TabIndex = 267
        Me.PictureBox104.TabStop = False
        '
        'PictureBox105
        '
        Me.PictureBox105.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox105.Location = New System.Drawing.Point(300, 350)
        Me.PictureBox105.Name = "PictureBox105"
        Me.PictureBox105.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox105.TabIndex = 266
        Me.PictureBox105.TabStop = False
        '
        'PictureBox106
        '
        Me.PictureBox106.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox106.Location = New System.Drawing.Point(275, 350)
        Me.PictureBox106.Name = "PictureBox106"
        Me.PictureBox106.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox106.TabIndex = 265
        Me.PictureBox106.TabStop = False
        '
        'PictureBox107
        '
        Me.PictureBox107.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox107.Location = New System.Drawing.Point(250, 350)
        Me.PictureBox107.Name = "PictureBox107"
        Me.PictureBox107.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox107.TabIndex = 264
        Me.PictureBox107.TabStop = False
        '
        'PictureBox108
        '
        Me.PictureBox108.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox108.Location = New System.Drawing.Point(225, 350)
        Me.PictureBox108.Name = "PictureBox108"
        Me.PictureBox108.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox108.TabIndex = 263
        Me.PictureBox108.TabStop = False
        '
        'PictureBox109
        '
        Me.PictureBox109.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox109.Location = New System.Drawing.Point(200, 350)
        Me.PictureBox109.Name = "PictureBox109"
        Me.PictureBox109.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox109.TabIndex = 262
        Me.PictureBox109.TabStop = False
        '
        'PictureBox110
        '
        Me.PictureBox110.Image = Global.DK2020.My.Resources.Resources.circleY
        Me.PictureBox110.Location = New System.Drawing.Point(175, 350)
        Me.PictureBox110.Name = "PictureBox110"
        Me.PictureBox110.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox110.TabIndex = 261
        Me.PictureBox110.TabStop = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label1.Location = New System.Drawing.Point(276, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 41)
        Me.Label1.TabIndex = 271
        Me.Label1.Text = "If correct"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(321, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(265, 41)
        Me.Label2.TabIndex = 272
        Me.Label2.Text = "If correct"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.Label2.Visible = False
        '
        'Button4
        '
        Me.Button4.Enabled = False
        Me.Button4.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(411, 560)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(103, 29)
        Me.Button4.TabIndex = 281
        Me.Button4.Text = "Vis udfald"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(411, 521)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(161, 29)
        Me.Button2.TabIndex = 280
        Me.Button2.Text = "Vis beslutning"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 601)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(521, 28)
        Me.Label6.TabIndex = 279
        Me.Label6.Text = "Beslutning nr"
        Me.Label6.Visible = False
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(-3, 523)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(336, 28)
        Me.Label5.TabIndex = 278
        Me.Label5.Text = "Kast en ti-sidet og en fire-sidet terning"
        '
        'NumericUpDown4
        '
        Me.NumericUpDown4.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown4.Location = New System.Drawing.Point(350, 521)
        Me.NumericUpDown4.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Size = New System.Drawing.Size(40, 29)
        Me.NumericUpDown4.TabIndex = 277
        Me.NumericUpDown4.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Enabled = False
        Me.NumericUpDown2.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown2.Location = New System.Drawing.Point(350, 562)
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(40, 29)
        Me.NumericUpDown2.TabIndex = 276
        Me.NumericUpDown2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 564)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(259, 28)
        Me.Label3.TabIndex = 275
        Me.Label3.Text = "Kast to ti-sidede terninger"
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(535, 560)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(134, 29)
        Me.Button5.TabIndex = 274
        Me.Button5.Text = "Ingen gevinst"
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(535, 597)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(134, 32)
        Me.Button3.TabIndex = 273
        Me.Button3.Text = "Forts�t"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(13, 378)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(610, 28)
        Me.Label4.TabIndex = 282
        Me.Label4.Text = "Lottery Valgmulighed A"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label4.Visible = False
        '
        'DK_ATTENTION_RESULTS2
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(681, 641)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.NumericUpDown4)
        Me.Controls.Add(Me.NumericUpDown2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox101)
        Me.Controls.Add(Me.PictureBox102)
        Me.Controls.Add(Me.PictureBox103)
        Me.Controls.Add(Me.PictureBox104)
        Me.Controls.Add(Me.PictureBox105)
        Me.Controls.Add(Me.PictureBox106)
        Me.Controls.Add(Me.PictureBox107)
        Me.Controls.Add(Me.PictureBox108)
        Me.Controls.Add(Me.PictureBox109)
        Me.Controls.Add(Me.PictureBox110)
        Me.Controls.Add(Me.PictureBox91)
        Me.Controls.Add(Me.PictureBox92)
        Me.Controls.Add(Me.PictureBox93)
        Me.Controls.Add(Me.PictureBox94)
        Me.Controls.Add(Me.PictureBox95)
        Me.Controls.Add(Me.PictureBox96)
        Me.Controls.Add(Me.PictureBox97)
        Me.Controls.Add(Me.PictureBox98)
        Me.Controls.Add(Me.PictureBox99)
        Me.Controls.Add(Me.PictureBox100)
        Me.Controls.Add(Me.PictureBox81)
        Me.Controls.Add(Me.PictureBox82)
        Me.Controls.Add(Me.PictureBox83)
        Me.Controls.Add(Me.PictureBox84)
        Me.Controls.Add(Me.PictureBox85)
        Me.Controls.Add(Me.PictureBox86)
        Me.Controls.Add(Me.PictureBox87)
        Me.Controls.Add(Me.PictureBox88)
        Me.Controls.Add(Me.PictureBox89)
        Me.Controls.Add(Me.PictureBox90)
        Me.Controls.Add(Me.PictureBox71)
        Me.Controls.Add(Me.PictureBox72)
        Me.Controls.Add(Me.PictureBox73)
        Me.Controls.Add(Me.PictureBox74)
        Me.Controls.Add(Me.PictureBox75)
        Me.Controls.Add(Me.PictureBox76)
        Me.Controls.Add(Me.PictureBox77)
        Me.Controls.Add(Me.PictureBox78)
        Me.Controls.Add(Me.PictureBox79)
        Me.Controls.Add(Me.PictureBox80)
        Me.Controls.Add(Me.PictureBox61)
        Me.Controls.Add(Me.PictureBox62)
        Me.Controls.Add(Me.PictureBox63)
        Me.Controls.Add(Me.PictureBox64)
        Me.Controls.Add(Me.PictureBox65)
        Me.Controls.Add(Me.PictureBox66)
        Me.Controls.Add(Me.PictureBox67)
        Me.Controls.Add(Me.PictureBox68)
        Me.Controls.Add(Me.PictureBox69)
        Me.Controls.Add(Me.PictureBox70)
        Me.Controls.Add(Me.PictureBox51)
        Me.Controls.Add(Me.PictureBox52)
        Me.Controls.Add(Me.PictureBox53)
        Me.Controls.Add(Me.PictureBox54)
        Me.Controls.Add(Me.PictureBox55)
        Me.Controls.Add(Me.PictureBox56)
        Me.Controls.Add(Me.PictureBox57)
        Me.Controls.Add(Me.PictureBox58)
        Me.Controls.Add(Me.PictureBox59)
        Me.Controls.Add(Me.PictureBox60)
        Me.Controls.Add(Me.PictureBox41)
        Me.Controls.Add(Me.PictureBox42)
        Me.Controls.Add(Me.PictureBox43)
        Me.Controls.Add(Me.PictureBox44)
        Me.Controls.Add(Me.PictureBox45)
        Me.Controls.Add(Me.PictureBox46)
        Me.Controls.Add(Me.PictureBox47)
        Me.Controls.Add(Me.PictureBox48)
        Me.Controls.Add(Me.PictureBox49)
        Me.Controls.Add(Me.PictureBox50)
        Me.Controls.Add(Me.PictureBox31)
        Me.Controls.Add(Me.PictureBox32)
        Me.Controls.Add(Me.PictureBox33)
        Me.Controls.Add(Me.PictureBox34)
        Me.Controls.Add(Me.PictureBox35)
        Me.Controls.Add(Me.PictureBox36)
        Me.Controls.Add(Me.PictureBox37)
        Me.Controls.Add(Me.PictureBox38)
        Me.Controls.Add(Me.PictureBox39)
        Me.Controls.Add(Me.PictureBox40)
        Me.Controls.Add(Me.PictureBox21)
        Me.Controls.Add(Me.PictureBox22)
        Me.Controls.Add(Me.PictureBox23)
        Me.Controls.Add(Me.PictureBox24)
        Me.Controls.Add(Me.PictureBox25)
        Me.Controls.Add(Me.PictureBox26)
        Me.Controls.Add(Me.PictureBox27)
        Me.Controls.Add(Me.PictureBox28)
        Me.Controls.Add(Me.PictureBox29)
        Me.Controls.Add(Me.PictureBox30)
        Me.Controls.Add(Me.IfCorrect)
        Me.Controls.Add(Me.Choose52)
        Me.Controls.Add(Me.Choose51)
        Me.Controls.Add(Me.Choose50)
        Me.Controls.Add(Me.Choose49)
        Me.Controls.Add(Me.PictureBox11)
        Me.Controls.Add(Me.PictureBox12)
        Me.Controls.Add(Me.PictureBox13)
        Me.Controls.Add(Me.PictureBox14)
        Me.Controls.Add(Me.PictureBox15)
        Me.Controls.Add(Me.PictureBox16)
        Me.Controls.Add(Me.PictureBox17)
        Me.Controls.Add(Me.PictureBox18)
        Me.Controls.Add(Me.PictureBox19)
        Me.Controls.Add(Me.PictureBox20)
        Me.Controls.Add(Me.IDlabel)
        Me.Controls.Add(Me.Choose48)
        Me.Controls.Add(Me.Infortext)
        Me.Controls.Add(Me.Header)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "DK_ATTENTION_RESULTS2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region
    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                             "GetPrivateProfileStringA" (ByVal lpApplicationName _
                             As String, ByVal lpKeyName As String, ByVal lpDefault _
                             As String, ByVal lpReturnedString As String, ByVal _
                             nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub


    Private Sub WriteToFile(ByVal TaskId As String,
                            ByVal Decision As String,
                            ByVal PrizeA1 As Single,
                            ByVal PrizeA2 As Single,
                            ByVal PrizeA3 As Single,
                            ByVal PrizeB1 As Single,
                            ByVal PrizeB2 As Single,
                            ByVal PrizeB3 As Single,
                            ByVal ProbA1 As Single,
                            ByVal ProbA2 As Single,
                            ByVal ProbA3 As Single,
                            ByVal ProbB1 As Single,
                            ByVal ProbB2 As Single,
                            ByVal ProbB3 As Single,
                            ByVal Endowment As Single,
                            ByVal qid As String,
                            ByVal Mixed As Single,
                            ByVal Loss As Single,
                            ByVal LotSet As Single,
                            ByVal Pair As Single,
                            ByVal ChoiceA As Single,
                            ByVal ChoiceB As Single,
        ByVal ImageN As Single,
        ByVal ProbG As Single,
                            ByVal Points As Single,
                            ByVal pickedprob As Single,
                            ByVal period As Single,
                            ByVal choice1 As Single,
                            ByVal choice2 As Single,
                            ByVal realization As Single,
                            ByVal Question As String,
                            ByVal answer As String,
                            ByVal roll40 As Single,
                            ByVal roll100 As Single,
                            ByVal earnings As Single
                            )

        Dim empty As String = 999

        Dim sFile As StreamWriter
        Dim line As String
        Dim sDate, sTime As String
        sDate = DateString
        sTime = TimeString
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        sFile = File.AppendText("../Data/AT_" & userId & ".txt")
        line = userId & ";" & sDate & ";" & sTime & ";" & TaskId & ";" & Decision & ";" &
            PrizeA1 & ";" & PrizeA2 & ";" & PrizeA3 & ";" & PrizeB1 & ";" & PrizeB2 & ";" & PrizeB3 & ";" &
ProbA1 & ";" & ProbA2 & ";" & ProbA3 & ";" & ProbB1 & ";" & ProbB2 & ";" & ProbB3 & ";" &
Endowment & ";" & qid & ";" & Mixed & ";" & Loss & ";" & LotSet & ";" & Pair & ";" & ChoiceA & ";" & ChoiceB & ";" &
        ImageN & ";" & ProbG & ";" & Points & ";" & pickedprob & ";" &
        period & ";" & choice1 & ";" & choice2 & ";" & realization & ";" &
        Question & ";" & answer & ";" &
        roll40 & ";" & roll100 & ";" & earnings
        sFile.WriteLine(line)
        sFile.Close()
    End Sub


    Private Function GetColor(ByVal itemIndex As Integer) As Color
        Dim objColor As Color
        Select Case itemIndex
            Case 0
                objColor = Color.LightBlue
            Case 1
                objColor = Color.LightGray
            Case 2
                objColor = Color.LightSalmon
            Case 3
                objColor = Color.Honeydew
            Case 4
                objColor = Color.Red
            Case 5
                objColor = Color.Green
            Case 6
                objColor = Color.Gray
            Case 7
                objColor = Color.Maroon
            Case Else
                objColor = Color.Green
        End Select
        Return objColor
    End Function

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
        If MsgBoxResult.Cancel = MsgBox("Er dette korrekt?", MsgBoxStyle.OkCancel, "Ingen gevinst") Then
            Exit Sub
        End If
        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
        writeINI(sStageFile, "Stage", "Stage", "EARNINGS")
        Dim DK2009 As New Earnings
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        ' Get basic lottery

        Dim Task As Integer

        ' Find out which lottery is played
        Dim value As Single
        value = NumericUpDown4.Value
        Select Case value
            Case 0
                Task = 40
            Case Else
                Task = value
        End Select

        Dim ATchoice As Integer = sGetINI(sResultsFile, "ChoiceAT", Task, 0)

        Dim strtempA As String = "ATtask " & Task

        ' Dim lottery information
        Dim tempProbG As String
        Dim tempPoints As String

        tempProbG = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbG", 0))
        tempPoints = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "Points", 0))
        Dim tempRollD As Single = NumericUpDown2.Value

        Dim amount As String = ""
        Select Case tempProbG
            Case 48
                Select Case ATchoice
                    Case 48
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 1000)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 2000)
                        Else
                            amount = "0 kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                        End If
                    Case Else
                        amount = "0 kr."
                        WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                End Select
            Case 49
                Select Case ATchoice
                    Case 49
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 1000)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 2000)
                        Else
                            amount = "0 kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                        End If
                    Case Else
                        amount = "0 kr."
                        WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                End Select
            Case 50
                Select Case ATchoice
                    Case 50
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 1000)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 2000)
                        Else
                            amount = "0 kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                        End If
                    Case Else
                        amount = "0 kr."
                        WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)

                End Select
            Case 51
                Select Case ATchoice
                    Case 51
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 1000)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 2000)
                        Else
                            amount = "0 kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                        End If
                    Case Else
                        amount = "0 kr."
                        WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                End Select
            Case 52
                Select Case ATchoice
                    Case 52
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 1000)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 2000)
                        Else
                            amount = "0 kr."
                            WriteToFile("ATearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumericUpDown4.Value, NumericUpDown2.Value, 0)
                            writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                        End If
                    Case Else
                        amount = "0 kr."
                        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
                End Select
        End Select


        If MsgBoxResult.Cancel = MsgBox("Din gevinst er " & amount, MsgBoxStyle.OkCancel, "Gevinst") Then
            Exit Sub
        End If

        writeINI(sStageFile, "Stage", "Stage", "EARNINGS")
        Dim DK2009 As New Earnings
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()
    End Sub


    Private Sub LoadTask(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.PictureBox11.Visible = False
        Me.PictureBox12.Visible = False
        Me.PictureBox13.Visible = False
        Me.PictureBox14.Visible = False
        Me.PictureBox15.Visible = False
        Me.PictureBox16.Visible = False
        Me.PictureBox17.Visible = False
        Me.PictureBox18.Visible = False
        Me.PictureBox19.Visible = False

        Me.PictureBox20.Visible = False
        Me.PictureBox21.Visible = False
        Me.PictureBox22.Visible = False
        Me.PictureBox23.Visible = False
        Me.PictureBox24.Visible = False
        Me.PictureBox25.Visible = False
        Me.PictureBox26.Visible = False
        Me.PictureBox27.Visible = False
        Me.PictureBox28.Visible = False
        Me.PictureBox29.Visible = False

        Me.PictureBox30.Visible = False
        Me.PictureBox31.Visible = False
        Me.PictureBox32.Visible = False
        Me.PictureBox33.Visible = False
        Me.PictureBox34.Visible = False
        Me.PictureBox35.Visible = False
        Me.PictureBox36.Visible = False
        Me.PictureBox37.Visible = False
        Me.PictureBox38.Visible = False
        Me.PictureBox39.Visible = False

        Me.PictureBox40.Visible = False
        Me.PictureBox41.Visible = False
        Me.PictureBox42.Visible = False
        Me.PictureBox43.Visible = False
        Me.PictureBox44.Visible = False
        Me.PictureBox45.Visible = False
        Me.PictureBox46.Visible = False
        Me.PictureBox47.Visible = False
        Me.PictureBox48.Visible = False
        Me.PictureBox49.Visible = False

        Me.PictureBox50.Visible = False
        Me.PictureBox51.Visible = False
        Me.PictureBox52.Visible = False
        Me.PictureBox53.Visible = False
        Me.PictureBox54.Visible = False
        Me.PictureBox55.Visible = False
        Me.PictureBox56.Visible = False
        Me.PictureBox57.Visible = False
        Me.PictureBox58.Visible = False
        Me.PictureBox59.Visible = False

        Me.PictureBox60.Visible = False
        Me.PictureBox61.Visible = False
        Me.PictureBox62.Visible = False
        Me.PictureBox63.Visible = False
        Me.PictureBox64.Visible = False
        Me.PictureBox65.Visible = False
        Me.PictureBox66.Visible = False
        Me.PictureBox67.Visible = False
        Me.PictureBox68.Visible = False
        Me.PictureBox69.Visible = False

        Me.PictureBox70.Visible = False
        Me.PictureBox71.Visible = False
        Me.PictureBox72.Visible = False
        Me.PictureBox73.Visible = False
        Me.PictureBox74.Visible = False
        Me.PictureBox75.Visible = False
        Me.PictureBox76.Visible = False
        Me.PictureBox77.Visible = False
        Me.PictureBox78.Visible = False
        Me.PictureBox79.Visible = False

        Me.PictureBox80.Visible = False
        Me.PictureBox81.Visible = False
        Me.PictureBox82.Visible = False
        Me.PictureBox83.Visible = False
        Me.PictureBox84.Visible = False
        Me.PictureBox85.Visible = False
        Me.PictureBox86.Visible = False
        Me.PictureBox87.Visible = False
        Me.PictureBox88.Visible = False
        Me.PictureBox89.Visible = False

        Me.PictureBox90.Visible = False
        Me.PictureBox91.Visible = False
        Me.PictureBox92.Visible = False
        Me.PictureBox93.Visible = False
        Me.PictureBox94.Visible = False
        Me.PictureBox95.Visible = False
        Me.PictureBox96.Visible = False
        Me.PictureBox97.Visible = False
        Me.PictureBox98.Visible = False
        Me.PictureBox99.Visible = False

        Me.PictureBox100.Visible = False
        Me.PictureBox101.Visible = False
        Me.PictureBox102.Visible = False
        Me.PictureBox103.Visible = False
        Me.PictureBox104.Visible = False
        Me.PictureBox105.Visible = False
        Me.PictureBox106.Visible = False
        Me.PictureBox107.Visible = False
        Me.PictureBox108.Visible = False
        Me.PictureBox109.Visible = False

        Me.PictureBox110.Visible = False
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")

        Me.IDlabel.Text = "ID: " & userId
        Me.Header.Text = "Find gevinst"
        Me.IfCorrect.Visible = False
        Me.Label1.Visible = False
        Me.Choose48.Enabled = False
        Me.Choose49.Enabled = False
        Me.Choose50.Enabled = False
        Me.Choose51.Enabled = False
        Me.Choose52.Enabled = False


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Me.Button4.Enabled = True



        Me.PictureBox11.Visible = True
        Me.PictureBox12.Visible = True
        Me.PictureBox13.Visible = True
        Me.PictureBox14.Visible = True
        Me.PictureBox15.Visible = True
        Me.PictureBox16.Visible = True
        Me.PictureBox17.Visible = True
        Me.PictureBox18.Visible = True
        Me.PictureBox19.Visible = True

        Me.PictureBox20.Visible = True
        Me.PictureBox21.Visible = True
        Me.PictureBox22.Visible = True
        Me.PictureBox23.Visible = True
        Me.PictureBox24.Visible = True
        Me.PictureBox25.Visible = True
        Me.PictureBox26.Visible = True
        Me.PictureBox27.Visible = True
        Me.PictureBox28.Visible = True
        Me.PictureBox29.Visible = True

        Me.PictureBox30.Visible = True
        Me.PictureBox31.Visible = True
        Me.PictureBox32.Visible = True
        Me.PictureBox33.Visible = True
        Me.PictureBox34.Visible = True
        Me.PictureBox35.Visible = True
        Me.PictureBox36.Visible = True
        Me.PictureBox37.Visible = True
        Me.PictureBox38.Visible = True
        Me.PictureBox39.Visible = True

        Me.PictureBox40.Visible = True
        Me.PictureBox41.Visible = True
        Me.PictureBox42.Visible = True
        Me.PictureBox43.Visible = True
        Me.PictureBox44.Visible = True
        Me.PictureBox45.Visible = True
        Me.PictureBox46.Visible = True
        Me.PictureBox47.Visible = True
        Me.PictureBox48.Visible = True
        Me.PictureBox49.Visible = True

        Me.PictureBox50.Visible = True
        Me.PictureBox51.Visible = True
        Me.PictureBox52.Visible = True
        Me.PictureBox53.Visible = True
        Me.PictureBox54.Visible = True
        Me.PictureBox55.Visible = True
        Me.PictureBox56.Visible = True
        Me.PictureBox57.Visible = True
        Me.PictureBox58.Visible = True
        Me.PictureBox59.Visible = True

        Me.PictureBox60.Visible = True
        Me.PictureBox61.Visible = True
        Me.PictureBox62.Visible = True
        Me.PictureBox63.Visible = True
        Me.PictureBox64.Visible = True
        Me.PictureBox65.Visible = True
        Me.PictureBox66.Visible = True
        Me.PictureBox67.Visible = True
        Me.PictureBox68.Visible = True
        Me.PictureBox69.Visible = True

        Me.PictureBox70.Visible = True
        Me.PictureBox71.Visible = True
        Me.PictureBox72.Visible = True
        Me.PictureBox73.Visible = True
        Me.PictureBox74.Visible = True
        Me.PictureBox75.Visible = True
        Me.PictureBox76.Visible = True
        Me.PictureBox77.Visible = True
        Me.PictureBox78.Visible = True
        Me.PictureBox79.Visible = True

        Me.PictureBox80.Visible = True
        Me.PictureBox81.Visible = True
        Me.PictureBox82.Visible = True
        Me.PictureBox83.Visible = True
        Me.PictureBox84.Visible = True
        Me.PictureBox85.Visible = True
        Me.PictureBox86.Visible = True
        Me.PictureBox87.Visible = True
        Me.PictureBox88.Visible = True
        Me.PictureBox89.Visible = True

        Me.PictureBox90.Visible = True
        Me.PictureBox91.Visible = True
        Me.PictureBox92.Visible = True
        Me.PictureBox93.Visible = True
        Me.PictureBox94.Visible = True
        Me.PictureBox95.Visible = True
        Me.PictureBox96.Visible = True
        Me.PictureBox97.Visible = True
        Me.PictureBox98.Visible = True
        Me.PictureBox99.Visible = True

        Me.PictureBox100.Visible = True
        Me.PictureBox101.Visible = True
        Me.PictureBox102.Visible = True
        Me.PictureBox103.Visible = True
        Me.PictureBox104.Visible = True
        Me.PictureBox105.Visible = True
        Me.PictureBox106.Visible = True
        Me.PictureBox107.Visible = True
        Me.PictureBox108.Visible = True
        Me.PictureBox109.Visible = True

        Me.PictureBox110.Visible = True

        ' OK button is inaktive

        Dim Task As Integer

        ' Find out which lottery is played
        Dim value As Single
        value = NumericUpDown4.Value
        Select Case value
            Case 0
                Task = 40
            Case Else
                Task = value
        End Select
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")

        Me.Header.Text = "Beslutning " & Task & " of 40"

        ' Dim lottery information
        Dim strtempA As String = "ATtask " & Task

        ' Dim lottery information
        Dim tempProbG As String
        Dim tempPoints As String

        ' Get basic lottery
        tempProbG = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbG", 0))
        tempPoints = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "Points", 0))

        Me.IfCorrect.Text = "Hvis du v�lger korrekt har du en "
        Me.Label1.Text = tempPoints & "%"
        Me.Label1.Font = New System.Drawing.Font("Garamond", 18.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Text = "chance for at vinde 2.000 kr."
        Me.Infortext.Text = "Hvor mange bl� bolde er der i figuren? V�lg dit svar herunder."

        Me.IfCorrect.Visible = True
        Me.Infortext.Visible = True
        Me.Label1.Visible = True
        Me.Label2.Visible = True


        Me.IfCorrect.Visible = True
        Me.Label4.Text = "Der er  " & tempProbG & " bl� bolde i figuren"
        Me.Label4.Visible = True

        Me.Choose48.Enabled = False
        Me.Choose49.Enabled = False
        Me.Choose50.Enabled = False
        Me.Choose51.Enabled = False
        Me.Choose52.Enabled = False

        ' Now make the randomization of the green and red dots
        Dim q As Integer = 1
        Dim tempGreen(100) As Integer
        Do While q < 101
            tempGreen(q) = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "pic" & q, 0))
            q = q + 1
        Loop

        If tempGreen(1) = 0 Then
            Me.PictureBox11.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox11.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(2) = 0 Then
            Me.PictureBox12.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox12.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(3) = 0 Then
            Me.PictureBox13.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox13.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(4) = 0 Then
            Me.PictureBox14.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox14.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(5) = 0 Then
            Me.PictureBox15.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox15.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(6) = 0 Then
            Me.PictureBox16.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox16.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(7) = 0 Then
            Me.PictureBox17.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox17.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(8) = 0 Then
            Me.PictureBox18.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox18.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(9) = 0 Then
            Me.PictureBox19.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox19.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(10) = 0 Then
            Me.PictureBox20.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox20.Image = DK2020.My.Resources.circleB
        End If

        ' 20
        If tempGreen(11) = 0 Then
            Me.PictureBox21.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox21.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(12) = 0 Then
            Me.PictureBox22.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox22.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(13) = 0 Then
            Me.PictureBox23.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox23.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(14) = 0 Then
            Me.PictureBox24.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox24.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(15) = 0 Then
            Me.PictureBox25.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox25.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(16) = 0 Then
            Me.PictureBox26.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox26.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(17) = 0 Then
            Me.PictureBox27.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox27.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(18) = 0 Then
            Me.PictureBox28.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox28.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(19) = 0 Then
            Me.PictureBox29.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox29.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(20) = 0 Then
            Me.PictureBox30.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox30.Image = DK2020.My.Resources.circleB
        End If


        ' 30ies
        If tempGreen(21) = 0 Then
            Me.PictureBox31.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox31.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(22) = 0 Then
            Me.PictureBox32.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox32.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(23) = 0 Then
            Me.PictureBox33.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox33.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(24) = 0 Then
            Me.PictureBox34.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox34.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(25) = 0 Then
            Me.PictureBox35.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox35.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(26) = 0 Then
            Me.PictureBox36.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox36.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(27) = 0 Then
            Me.PictureBox37.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox37.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(28) = 0 Then
            Me.PictureBox38.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox38.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(29) = 0 Then
            Me.PictureBox39.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox39.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(30) = 0 Then
            Me.PictureBox40.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox40.Image = DK2020.My.Resources.circleB
        End If


        '40
        If tempGreen(31) = 0 Then
            Me.PictureBox41.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox41.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(32) = 0 Then
            Me.PictureBox42.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox42.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(33) = 0 Then
            Me.PictureBox43.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox43.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(34) = 0 Then
            Me.PictureBox44.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox44.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(35) = 0 Then
            Me.PictureBox45.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox45.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(36) = 0 Then
            Me.PictureBox46.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox46.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(37) = 0 Then
            Me.PictureBox47.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox47.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(38) = 0 Then
            Me.PictureBox48.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox48.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(39) = 0 Then
            Me.PictureBox49.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox49.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(40) = 0 Then
            Me.PictureBox50.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox50.Image = DK2020.My.Resources.circleB
        End If


        '50
        If tempGreen(41) = 0 Then
            Me.PictureBox51.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox51.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(42) = 0 Then
            Me.PictureBox52.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox52.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(43) = 0 Then
            Me.PictureBox53.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox53.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(44) = 0 Then
            Me.PictureBox54.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox54.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(45) = 0 Then
            Me.PictureBox55.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox55.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(46) = 0 Then
            Me.PictureBox56.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox56.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(47) = 0 Then
            Me.PictureBox57.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox57.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(48) = 0 Then
            Me.PictureBox58.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox58.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(49) = 0 Then
            Me.PictureBox59.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox59.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(50) = 0 Then
            Me.PictureBox60.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox60.Image = DK2020.My.Resources.circleB
        End If

        '60
        If tempGreen(51) = 0 Then
            Me.PictureBox61.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox61.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(52) = 0 Then
            Me.PictureBox62.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox62.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(53) = 0 Then
            Me.PictureBox63.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox63.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(54) = 0 Then
            Me.PictureBox64.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox64.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(55) = 0 Then
            Me.PictureBox65.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox65.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(56) = 0 Then
            Me.PictureBox66.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox66.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(57) = 0 Then
            Me.PictureBox67.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox67.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(58) = 0 Then
            Me.PictureBox68.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox68.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(59) = 0 Then
            Me.PictureBox69.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox69.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(60) = 0 Then
            Me.PictureBox70.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox70.Image = DK2020.My.Resources.circleB
        End If

        '70
        If tempGreen(61) = 0 Then
            Me.PictureBox71.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox71.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(62) = 0 Then
            Me.PictureBox72.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox72.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(63) = 0 Then
            Me.PictureBox73.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox73.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(64) = 0 Then
            Me.PictureBox74.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox74.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(65) = 0 Then
            Me.PictureBox75.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox75.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(66) = 0 Then
            Me.PictureBox76.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox76.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(67) = 0 Then
            Me.PictureBox77.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox77.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(68) = 0 Then
            Me.PictureBox78.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox78.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(69) = 0 Then
            Me.PictureBox79.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox79.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(70) = 0 Then
            Me.PictureBox80.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox80.Image = DK2020.My.Resources.circleB
        End If

        '80
        If tempGreen(71) = 0 Then
            Me.PictureBox81.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox81.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(72) = 0 Then
            Me.PictureBox82.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox82.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(73) = 0 Then
            Me.PictureBox83.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox83.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(74) = 0 Then
            Me.PictureBox84.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox84.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(75) = 0 Then
            Me.PictureBox85.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox85.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(76) = 0 Then
            Me.PictureBox86.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox86.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(77) = 0 Then
            Me.PictureBox87.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox87.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(78) = 0 Then
            Me.PictureBox88.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox88.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(79) = 0 Then
            Me.PictureBox89.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox89.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(80) = 0 Then
            Me.PictureBox90.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox90.Image = DK2020.My.Resources.circleB
        End If
        '90

        If tempGreen(81) = 0 Then
            Me.PictureBox91.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox91.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(82) = 0 Then
            Me.PictureBox92.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox92.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(83) = 0 Then
            Me.PictureBox93.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox93.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(84) = 0 Then
            Me.PictureBox94.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox94.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(85) = 0 Then
            Me.PictureBox95.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox95.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(86) = 0 Then
            Me.PictureBox96.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox96.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(87) = 0 Then
            Me.PictureBox97.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox97.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(88) = 0 Then
            Me.PictureBox98.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox98.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(89) = 0 Then
            Me.PictureBox99.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox99.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(90) = 0 Then
            Me.PictureBox100.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox100.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(91) = 0 Then
            Me.PictureBox101.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox101.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(92) = 0 Then
            Me.PictureBox102.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox102.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(93) = 0 Then
            Me.PictureBox103.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox103.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(94) = 0 Then
            Me.PictureBox104.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox104.Image = DK2020.My.Resources.circleB
        End If

        If tempGreen(95) = 0 Then
            Me.PictureBox105.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox105.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(96) = 0 Then
            Me.PictureBox106.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox106.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(97) = 0 Then
            Me.PictureBox107.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox107.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(98) = 0 Then
            Me.PictureBox108.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox108.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(99) = 0 Then
            Me.PictureBox109.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox109.Image = DK2020.My.Resources.circleB
        End If
        If tempGreen(100) = 0 Then
            Me.PictureBox110.Image = DK2020.My.Resources.circleY
        Else
            Me.PictureBox110.Image = DK2020.My.Resources.circleB
        End If

        ' Choice
        Dim ATchoice As Integer = sGetINI(sResultsFile, "ChoiceAT", Task, 0)

        Select Case ATchoice
            Case 48
                Me.Choose48.Select()
                Me.Choose48.Enabled = True
                Me.Choose49.Enabled = False
                Me.Choose50.Enabled = False
                Me.Choose51.Enabled = False
                Me.Choose52.Enabled = False
            Case 49
                Me.Choose49.Select()
                Me.Choose48.Enabled = False
                Me.Choose49.Enabled = True
                Me.Choose50.Enabled = False
                Me.Choose51.Enabled = False
                Me.Choose52.Enabled = False
            Case 50
                Me.Choose50.Select()
                Me.Choose48.Enabled = False
                Me.Choose49.Enabled = False
                Me.Choose50.Enabled = True
                Me.Choose51.Enabled = False
                Me.Choose52.Enabled = False
            Case 51
                Me.Choose51.Select()
                Me.Choose48.Enabled = False
                Me.Choose49.Enabled = False
                Me.Choose50.Enabled = False
                Me.Choose51.Enabled = True
                Me.Choose52.Enabled = False
            Case 52
                Me.Choose52.Select()
                Me.Choose48.Enabled = False
                Me.Choose49.Enabled = False
                Me.Choose50.Enabled = False
                Me.Choose51.Enabled = False
                Me.Choose52.Enabled = True
        End Select

        Dim correct As Single = 0
        If tempProbG = ATchoice Then
            correct = 1
        End If

        Select Case correct
            Case 0
                Me.Infortext.Text = "Du svarede forkert med " & ATchoice & " bl� bolde"
                Me.Button5.Enabled = True
                Me.Button3.Enabled = False

            Case 1
                Me.Infortext.Text = "Du svarede korrekt med " & ATchoice & " bl� bolde"
                Me.Button5.Enabled = False
                Me.NumericUpDown2.Enabled = True

        End Select

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Dim Task As Integer
        ' Find out which lottery is played
        Dim value As Single
        value = NumericUpDown4.Value
        Select Case value
            Case 0
                Task = 40
            Case Else
                Task = value
        End Select

        Dim ATchoice As Integer = sGetINI(sResultsFile, "ChoiceAT", Task, 0)
        Dim strtempA As String = "ATtask " & Task

        ' Dim lottery information
        Dim tempProbG As String
        Dim tempPoints As String

        tempProbG = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "ProbG", 0))
        tempPoints = Convert.ToSingle(sGetINI(sSetupFile, strtempA, "Points", 0))
        Dim tempRollD As Single = NumericUpDown2.Value

        Dim amount As String = ""
        Select Case tempProbG
            Case 48
                Select Case ATchoice
                    Case 48
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er mindre eller lig med " & tempPoints & ", s� du vinder 2000 kr."
                            Me.Button5.Enabled = False
                            Me.Button3.Enabled = True

                        Else
                            amount = "0 kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er st�rre end " & tempPoints & ", s� du vinder ikke noget."
                            Me.Button3.Enabled = False
                            Me.Button5.Enabled = True
                        End If
                    Case Else
                        amount = "0 kr."
                End Select
            Case 49
                Select Case ATchoice
                    Case 49
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er mindre eller lig med " & tempPoints & ", s� du vinder 2000 kr."
                            Me.Button5.Enabled = False
                            Me.Button3.Enabled = True

                        Else
                            amount = "0 kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er st�rre end " & tempPoints & ", s� du vinder ikke noget."
                            Me.Button3.Enabled = False
                            Me.Button5.Enabled = True
                        End If
                    Case Else
                        amount = "0 kr."
                End Select
            Case 50
                Select Case ATchoice
                    Case 50
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er mindre eller lig med " & tempPoints & ", s� du vinder 2000 kr."
                            Me.Button5.Enabled = False
                            Me.Button3.Enabled = True

                        Else
                            amount = "0 kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er st�rre end " & tempPoints & ", s� du vinder ikke noget."
                            Me.Button3.Enabled = False
                            Me.Button5.Enabled = True
                        End If
                    Case Else
                        amount = "0 kr."
                End Select
            Case 51
                Select Case ATchoice
                    Case 51
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er mindre eller lig med " & tempPoints & ", s� du vinder 2000 kr."
                            Me.Button5.Enabled = False
                            Me.Button3.Enabled = True

                        Else
                            amount = "0 kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er st�rre end " & tempPoints & ", s� du vinder ikke noget."
                            Me.Button3.Enabled = False
                            Me.Button5.Enabled = True
                        End If
                    Case Else
                        amount = "0 kr."
                End Select
            Case 52
                Select Case ATchoice
                    Case 52
                        If tempRollD <= tempPoints Then
                            amount = Convert.ToString(2000) & " kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er mindre eller lig med " & tempPoints & ", s� du vinder 2000 kr."
                            Me.Button5.Enabled = False
                            Me.Button3.Enabled = True

                        Else
                            amount = "0 kr."
                            Label6.Text = "Udfaldet " & tempRollD & " er st�rre end " & tempPoints & ", s� du vinder ikke noget."
                            Me.Button3.Enabled = False
                            Me.Button5.Enabled = True
                        End If
                    Case Else
                        amount = "0 kr."
                End Select
        End Select
        Label6.Visible = True
    End Sub
End Class
