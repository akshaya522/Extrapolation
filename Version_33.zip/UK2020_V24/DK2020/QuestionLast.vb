
Imports System.Math
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Drawing.Graphics
Imports System.Windows.Forms.PaintEventArgs
Imports System.Threading
Public Class QuestionLast

    Inherits System.Windows.Forms.Form
    Private sInfoFile As String = "../tmpInfo.ini"
    Private sResultsFile As String = "../tmpResult.ini"
    Private sSetupFile As String = "../tmpSetup.ini"
    Private sEarningsFile As String = "../tmpEarnings.ini"
    Private sStageFile As String = "../tmpStage.ini"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Okbutton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Okbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Okbutton
        '
        Me.Okbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Okbutton.Font = New System.Drawing.Font("Garamond", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Okbutton.Location = New System.Drawing.Point(902, 207)
        Me.Okbutton.Name = "Okbutton"
        Me.Okbutton.Size = New System.Drawing.Size(122, 44)
        Me.Okbutton.TabIndex = 0
        Me.Okbutton.Text = "OK"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(21, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1003, 97)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Dette var det sidste sp�rgsm�l. Vi g�r nu videre med den sidste del af eksperimen" &
    "tet. Efter denne del vil du blive betalt, og du kan forlade eksperimentet. "
        '
        'QuestionLast
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1042, 270)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Okbutton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "QuestionLast"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region


    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                                "GetPrivateProfileStringA" (ByVal lpApplicationName _
                                As String, ByVal lpKeyName As String, ByVal lpDefault _
                                As String, ByVal lpReturnedString As String, ByVal _
                                nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub

    Private Sub Okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Okbutton.Click

        Dim Question As String
        Dim answer As String

        Question = "QX1"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX2"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX3"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX4"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX5"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX6"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX7"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX8"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX9"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX10_A"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX10_B"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX10_C"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX11_A"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX11_B"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX11_C"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX12_A"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX12_B"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX13_A"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX13_B"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX13_C"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX14_A"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX14_B"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX14_C"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX15_A"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX15_B"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX15_C"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)

        Question = "QX16"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX17"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX18"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX19"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX20"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX21"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX22"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX23"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX24"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX25"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX26"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX27"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX28"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX29"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX30"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX31"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX32"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX33"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX34"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX35"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        Question = "QX36"
        answer = sGetINI("../Quest.ini", "Sp�rgsm�l", Question, "NA")
        WriteToFile("QT", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Question, answer, 0, 0, 0)
        writeINI(sStageFile, "Stage", "Stage", "ATTENTION")

        ' Insert password
        Dim returnPSW As String = "0"
        Dim password As String = "4"
        Do While password <> returnPSW
            returnPSW = InputBox("Indtast adgangskode", "Adgangskode", "", 100, 100)
        Loop
        Dim infoAT As New InfoAT()
        infoAT.MdiParent = Me.MdiParent
        infoAT.Show()
        Me.Close()

    End Sub

    Private Sub WriteToFile(ByVal TaskId As String,
                            ByVal Decision As String,
                            ByVal PrizeA1 As Single,
                            ByVal PrizeA2 As Single,
                            ByVal PrizeA3 As Single,
                            ByVal PrizeB1 As Single,
                            ByVal PrizeB2 As Single,
                            ByVal PrizeB3 As Single,
                            ByVal ProbA1 As Single,
                            ByVal ProbA2 As Single,
                            ByVal ProbA3 As Single,
                            ByVal ProbB1 As Single,
                            ByVal ProbB2 As Single,
                            ByVal ProbB3 As Single,
                            ByVal Endowment As Single,
                            ByVal qid As String,
                            ByVal Mixed As Single,
                            ByVal Loss As Single,
                            ByVal LotSet As Single,
                            ByVal Pair As Single,
                            ByVal ChoiceA As Single,
                            ByVal ChoiceB As Single,
                            ByVal ImageN As Single,
                            ByVal ProbG As Single,
                            ByVal Points As Single,
                            ByVal pickedprob As Single,
                            ByVal period As Single,
                            ByVal choice1 As Single,
                            ByVal choice2 As Single,
                            ByVal realization As Single,
                            ByVal Question As String,
                            ByVal answer As String,
                            ByVal roll40 As Single,
                            ByVal roll100 As Single,
                            ByVal earnings As Single
                            )

        Dim empty As String = 999

        Dim sFile As StreamWriter
        Dim line As String
        Dim sDate, sTime As String
        sDate = DateString
        sTime = TimeString
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        sFile = File.AppendText("../Data/QT_" & userId & ".txt")
        line = userId & ";" & sDate & ";" & sTime & ";" & TaskId & ";" & Decision & ";" &
            PrizeA1 & ";" & PrizeA2 & ";" & PrizeA3 & ";" & PrizeB1 & ";" & PrizeB2 & ";" & PrizeB3 & ";" &
ProbA1 & ";" & ProbA2 & ";" & ProbA3 & ";" & ProbB1 & ";" & ProbB2 & ";" & ProbB3 & ";" &
Endowment & ";" & qid & ";" & Mixed & ";" & Loss & ";" & LotSet & ";" & Pair & ";" & ChoiceA & ";" & ChoiceB & ";" &
        ImageN & ";" & ProbG & ";" & Points & ";" & pickedprob & ";" &
        period & ";" & choice1 & ";" & choice2 & ";" & realization & ";" &
        Question & ";" & answer & ";" &
        roll40 & ";" & roll100 & ";" & earnings
        sFile.WriteLine(line)
        sFile.Close()
    End Sub
End Class
