Public Class QuestionX12

    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Okbutton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents Label5 As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents Label4 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TilbageButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Okbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TilbageButton = New System.Windows.Forms.Button()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Okbutton
        '
        Me.Okbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Okbutton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Okbutton.Location = New System.Drawing.Point(1024, 284)
        Me.Okbutton.Name = "Okbutton"
        Me.Okbutton.Size = New System.Drawing.Size(103, 37)
        Me.Okbutton.TabIndex = 0
        Me.Okbutton.Text = "OK"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(46, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1094, 55)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "12. I det n�ste sp�rgsm�l beder vi dig fort�lle hvor sandsynligt, du tror, det er" &
    ", at afkastet vil v�re inden for et specifikt interval."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TilbageButton
        '
        Me.TilbageButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TilbageButton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TilbageButton.Location = New System.Drawing.Point(912, 284)
        Me.TilbageButton.Name = "TilbageButton"
        Me.TilbageButton.Size = New System.Drawing.Size(102, 37)
        Me.TilbageButton.TabIndex = 19
        Me.TilbageButton.Text = "Tilbage"
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(171, 250)
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(59, 20)
        Me.NumericUpDown2.TabIndex = 44
        Me.NumericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(46, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(918, 48)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "10. BB"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(171, 160)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(59, 20)
        Me.NumericUpDown1.TabIndex = 40
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label4.Location = New System.Drawing.Point(80, 155)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(316, 24)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Der er en               pct. sandsynlighed"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(147, 203)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(357, 35)
        Me.Label14.TabIndex = 38
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(46, 102)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(848, 48)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "A.  AA"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label2.Location = New System.Drawing.Point(80, 245)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(316, 24)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "Der er en               pct. sandsynlighed"
        '
        'QuestionX12
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1139, 349)
        Me.ControlBox = False
        Me.Controls.Add(Me.NumericUpDown2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TilbageButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Okbutton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "QuestionX12"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                           "GetPrivateProfileStringA" (ByVal lpApplicationName _
                           As String, ByVal lpKeyName As String, ByVal lpDefault _
                           As String, ByVal lpReturnedString As String, ByVal _
                           nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub

    Public choiceA As Byte = 0
    Public choiceB As Byte = 0
    Public choiceC As Byte = 0


    Private Sub Okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Okbutton.Click

        If choiceA = 0 Then
            MsgBox("Please make selection for A", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If

        If choiceB = 0 Then
            MsgBox("Please make selection for B", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If

        writeINI("../Quest.ini", "Sp�rgsm�l", "QX12_A", NumericUpDown1.Value)
        writeINI("../Quest.ini", "Sp�rgsm�l", "QX12_B", NumericUpDown2.Value)

        Dim Forms As New QuestionX13()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()

    End Sub

    Private Sub LoadForm(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim valueA As Single = Convert.ToSingle(sGetINI("../Quest.ini", "Sp�rgsm�l", "QX10_A", "0"))

        Me.Okbutton.Enabled = False

        Label15.Text = "A. Hvor sandsynligt er det, at det gennemsnitlige �rlig afkast er mellem " & valueA - 5 & "% og " & valueA + 5 & " pct. over det n�ste �r?"
        Label5.Text = "B. B.	Hvor sandsynligt er det at det gennemsnitlige �rlig afkast over " & valueA + 5 & " pct. over det n�ste �r?"

        Label4.Text = "Der er en               pct. sandsynlighed"
        Label2.Text = "Der er en               pct. sandsynlighed"

        Select Case sGetINI("../Quest.ini", "Sp�rgsm�l", "QX12_A", "?")
            Case "?"
            Case Else
                NumericUpDown1.Value = sGetINI("../Quest.ini", "Sp�rgsm�l", "QX12_A", "?")
                NumericUpDown2.Value = sGetINI("../Quest.ini", "Sp�rgsm�l", "QX12_B", "?")
                Me.Okbutton.Enabled = True
        End Select

    End Sub

    Private Sub TilbageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TilbageButton.Click
        Dim Forms As New QuestionX11()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
        choiceA = 1
        If choiceA = 1 And choiceB = 1 Then
            Me.Okbutton.Enabled = True
        End If
    End Sub

    Private Sub NumericUpDown2_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown2.ValueChanged
        choiceB = 1
        If choiceA = 1 And choiceB = 1 Then
            Me.Okbutton.Enabled = True
        End If

    End Sub

End Class
