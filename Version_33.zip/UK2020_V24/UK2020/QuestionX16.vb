Public Class QuestionX16


    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Okbutton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TilbageButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Okbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TilbageButton = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Okbutton
        '
        Me.Okbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Okbutton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Okbutton.Location = New System.Drawing.Point(885, 290)
        Me.Okbutton.Name = "Okbutton"
        Me.Okbutton.Size = New System.Drawing.Size(102, 37)
        Me.Okbutton.TabIndex = 0
        Me.Okbutton.Text = "OK"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(46, 220)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(876, 38)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "What do you expect the average temperature in Copenhagen in August to be this yea" &
    "r:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TilbageButton
        '
        Me.TilbageButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TilbageButton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TilbageButton.Location = New System.Drawing.Point(773, 290)
        Me.TilbageButton.Name = "TilbageButton"
        Me.TilbageButton.Size = New System.Drawing.Size(102, 37)
        Me.TilbageButton.TabIndex = 19
        Me.TilbageButton.Text = "Tilbage"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label3.Location = New System.Drawing.Point(176, 256)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 24)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "degrees Celcius"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(50, 261)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(120, 20)
        Me.NumericUpDown1.TabIndex = 21
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(46, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(941, 48)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "16.  The historical average temperatures in Copenhagen in August over the past ye" &
    "ars were as follows:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(98, 59)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(848, 34)
        Me.Label17.TabIndex = 41
        Me.Label17.Text = "August 2019 = 19 degrees Celsius"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(98, 93)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(848, 29)
        Me.Label18.TabIndex = 42
        Me.Label18.Text = "August 2018 = 17 degrees Celsius"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(98, 122)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(848, 28)
        Me.Label19.TabIndex = 43
        Me.Label19.Text = "August 2017 = 17 degrees Celsius"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(98, 150)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(848, 28)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "August 2016 = 19 degrees Celsius"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(46, 194)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(876, 26)
        Me.Label4.TabIndex = 45
        Me.Label4.Text = "Average temperature in August from 1985-2015 was 17 degrees Celsius"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'QuestionX16
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1005, 346)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TilbageButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Okbutton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "QuestionX16"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                           "GetPrivateProfileStringA" (ByVal lpApplicationName _
                           As String, ByVal lpKeyName As String, ByVal lpDefault _
                           As String, ByVal lpReturnedString As String, ByVal _
                           nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub
    Public ChoiceA As Single = 0

    Private Sub Okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Okbutton.Click

        writeINI("../Quest.ini", "Sp�rgsm�l", "QX16", NumericUpDown1.Value)

        If ChoiceA = 0 Then
            MsgBox("Besvar venligst sp�rgsm�l A", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If
        Dim Forms As New QuestionX17()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()
    End Sub

    Private Sub LoadForm(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Okbutton.Enabled = False
        Select Case sGetINI("../Quest.ini", "Sp�rgsm�l", "QX16", "?")
            Case "?"
            Case Else
                NumericUpDown1.Value = sGetINI("../Quest.ini", "Sp�rgsm�l", "QX16", "?")
                Okbutton.Enabled = True
        End Select

    End Sub

    Private Sub TilbageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TilbageButton.Click

        Dim Forms As New QuestionX15()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()


    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
        ChoiceA = 1
        Me.Okbutton.Enabled = True

    End Sub

End Class
