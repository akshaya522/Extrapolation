Imports System.IO
Imports System.Drawing
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.Windows.Forms
Imports System.Windows.Forms.Design
Imports System.Data
Imports System.Reflection.Assembly
Imports System.Math
Imports System.Data.OleDb


Public Class IdRequest
    Inherits System.Windows.Forms.Form
    Public Start, Finish, Tasktime, taskNo As Double
    Private sInfoFile As String = "../tmpInfo.ini"
    Private sResultsFile As String = "../tmpResult.ini"
    Private sSetupFile As String = "../tmpSetup.ini"
    Private sEarningsFile As String = "../tmpEarnings.ini"
    Private sStageFile As String = "../tmpStage.ini"
    Friend WithEvents Logo As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents hdrDept As System.Windows.Forms.Label
    Friend WithEvents subID As System.Windows.Forms.TextBox
    Friend WithEvents lblId As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(IdRequest))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.hdrDept = New System.Windows.Forms.Label()
        Me.subID = New System.Windows.Forms.TextBox()
        Me.lblId = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Logo = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        CType(Me.Logo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button1.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(12, 311)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(147, 39)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = " Extrapolation"
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(12, 205)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(286, 45)
        Me.Label23.TabIndex = 13
        Me.Label23.Text = "Velkommen til unders�gelsen"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'hdrDept
        '
        Me.hdrDept.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDept.ForeColor = System.Drawing.Color.Black
        Me.hdrDept.Location = New System.Drawing.Point(12, 161)
        Me.hdrDept.Name = "hdrDept"
        Me.hdrDept.Size = New System.Drawing.Size(280, 44)
        Me.hdrDept.TabIndex = 11
        Me.hdrDept.Text = "Institut for Finansiering"
        Me.hdrDept.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'subID
        '
        Me.subID.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.subID.Location = New System.Drawing.Point(124, 261)
        Me.subID.Name = "subID"
        Me.subID.Size = New System.Drawing.Size(96, 29)
        Me.subID.TabIndex = 15
        Me.subID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblId
        '
        Me.lblId.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblId.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblId.Location = New System.Drawing.Point(12, 259)
        Me.lblId.Name = "lblId"
        Me.lblId.Size = New System.Drawing.Size(106, 29)
        Me.lblId.TabIndex = 14
        Me.lblId.Text = "Dit ID"
        Me.lblId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button3
        '
        Me.Button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button3.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(209, 367)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(147, 39)
        Me.Button3.TabIndex = 21
        Me.Button3.Text = "Restart"
        Me.Button3.Visible = False
        '
        'Logo
        '
        Me.Logo.Image = CType(resources.GetObject("Logo.Image"), System.Drawing.Image)
        Me.Logo.InitialImage = CType(resources.GetObject("Logo.InitialImage"), System.Drawing.Image)
        Me.Logo.Location = New System.Drawing.Point(12, 12)
        Me.Logo.Name = "Logo"
        Me.Logo.Size = New System.Drawing.Size(284, 146)
        Me.Logo.TabIndex = 45
        Me.Logo.TabStop = False
        '
        'Button2
        '
        Me.Button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button2.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(12, 367)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(147, 39)
        Me.Button2.TabIndex = 48
        Me.Button2.Text = "Attention"
        '
        'Button5
        '
        Me.Button5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button5.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(12, 428)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(147, 39)
        Me.Button5.TabIndex = 49
        Me.Button5.Text = "Risk Aversion"
        '
        'Button4
        '
        Me.Button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button4.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(209, 311)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(147, 39)
        Me.Button4.TabIndex = 50
        Me.Button4.Text = "Questionnaire"
        '
        'IdRequest
        '
        Me.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(382, 483)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Logo)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.subID)
        Me.Controls.Add(Me.lblId)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.hdrDept)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.Location = New System.Drawing.Point(400, 250)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "IdRequest"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.Logo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region


    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                        "GetPrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpDefault _
                        As String, ByVal lpReturnedString As String, ByVal _
                        nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer

    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function
    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Convert.ToString(subID.Text.Length) <> 4 Then
            MessageBox.Show("Dit ID")
            Exit Sub
        End If


        rerandomize()

        Dim DK2009 As New BeforeEX
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()

        Exit Sub


    End Sub



    Private Sub IDREQUEST_(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim DK2009 As New Earnings
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()
    End Sub

    Private Sub HdrDept_Click(sender As Object, e As EventArgs) Handles hdrDept.Click

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        Dim stage As String = sGetINI(sStageFile, "Stage", "Stage", "")

        Select Case stage
            Case "LOT"
                Dim DK2009 As New DK_LOT
                DK2009.MdiParent = Me.MdiParent
                DK2009.Show()
                Me.Close()
            Case "LOT_RESULTS"
                Dim DK2009 As New DK_LOT_RESULTS
                DK2009.MdiParent = Me.MdiParent
                DK2009.Show()
                Me.Close()
            Case "QUESTION"
                Dim DK2009 As New Question0
                DK2009.MdiParent = Me.MdiParent
                DK2009.Show()
                Me.Close()
            Case "EXTRACT_RESULTS"
                Dim DK2009 As New DK_EXTRACT2
                DK2009.MdiParent = Me.MdiParent
                DK2009.Show()
                Me.Close()
            Case "EXTRACT"
                Dim DK2009 As New DK_EXTRACT2
                DK2009.MdiParent = Me.MdiParent
                DK2009.Show()
                Me.Close()
            Case "EARNINGS"
                Dim DK2009 As New Earnings
                DK2009.MdiParent = Me.MdiParent
                DK2009.Show()
                Me.Close()
        End Select



    End Sub

    Private Sub WriteToFile(ByVal Setup1 As String,
                           ByVal setup2 As String,
                           ByVal setup3 As String,
                           ByVal setup4 As String,
                           ByVal setup5 As String,
                           ByVal setup6 As String,
                           ByVal setup7 As String,
                           ByVal setup8 As String,
                           ByVal setup9 As String,
                           ByVal setup10 As String,
                           ByVal setup11 As String,
                           ByVal setup12 As String,
                           ByVal setup13 As String,
                           ByVal setup14 As String,
                           ByVal setup15 As String,
                           ByVal setup16 As String,
                           ByVal setup17 As String,
                           ByVal setup18 As String,
                           ByVal setup19 As String,
                           ByVal setup20 As String,
                           ByVal setup21 As String)

        Dim empty As String = 999

        Dim sFile As StreamWriter
        Dim line As String
        Dim sDate, sTime As String
        sDate = DateString
        sTime = TimeString
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        sFile = File.AppendText("../Data/Setup_" & userId & ".txt")
        line = userId & ";" & sDate & ";" & sTime & ";" &
                Setup1 & ";" & setup2 & ";" & setup3 & ";" & setup4 & ";" & setup5 & ";" &
                setup6 & ";" & setup7 & ";" & setup8 & ";" & setup9 & ";" & setup10 & ";" &
                setup11 & ";" & setup12 & ";" & setup13 & ";" & setup14 & ";" & setup15 & ";" &
                setup16 & ";" & setup17 & ";" & setup18 & ";" & setup19 & ";" & setup20 & ";" & setup21

        sFile.WriteLine(line)
        sFile.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If Convert.ToString(subID.Text.Length) <> 4 Then
            MessageBox.Show("Dit ID")
            Exit Sub
        End If

        rerandomize()

        Dim DK2009 As New DK_ATTENTION
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()
        Exit Sub
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        If Convert.ToString(subID.Text.Length) <> 4 Then
            MessageBox.Show("Dit ID")
            Exit Sub
        End If

        rerandomize()

        Dim DK2009 As New BeforeLOT
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()

        Exit Sub

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click

        If Convert.ToString(subID.Text.Length) <> 4 Then
            MessageBox.Show("Dit ID")
            Exit Sub
        End If

        Dim DK2009 As New Question0
        DK2009.MdiParent = Me.MdiParent
        DK2009.Show()
        Me.Close()
    End Sub

    Private Sub rerandomize()

        ' ShowUpFee
        Dim ShowUp As Single = 0

        ' Insert right Session IDs here

        Dim High As Integer = 0
        Dim idN As Integer = Convert.ToSingle(Me.subID.Text)
        If idN > 4999 Then High = 1
        If High = 1 Then
            writeINI(sEarningsFile, "EARNINGS", "SHOWUP", 1000)
            ShowUp = 1000
        Else
            writeINI(sEarningsFile, "EARNINGS", "SHOWUP", 2000)
            ShowUp = 2000
        End If

        Dim Setup1 As Single = ShowUp


        ' RA task randomizations
        Dim RaTasksG As Int32() = Enumerable.Range(1, 16).ToArray()
        Dim RaTasksM As Int32() = Enumerable.Range(17, 24).ToArray()
        ' shuffle the order
        Randomize()
        Shuffle(RaTasksG)
        Shuffle(RaTasksM)

        ' ATTENTION task randomizations
        ' first randomize high stake stuff
        Dim LowIncentives As Int32() = Enumerable.Range(1, 20).ToArray()
        Dim HighIncentives As Int32() = Enumerable.Range(21, 20).ToArray()
        Shuffle(LowIncentives)
        Shuffle(HighIncentives)

        ' put first 10 of low incentives into Array
        Dim first20(19) As Integer
        Dim i As Integer
        i = 0
        Do While i < 10
            first20(i) = LowIncentives(i)
            i = i + 1
        Loop
        i = 0
        Do While i < 10
            first20(i + 10) = HighIncentives(i)
            i = i + 1
        Loop
        first20.ToArray
        Shuffle(first20)

        Dim last20(19) As Integer
        i = 0
        Do While i < 10
            last20(i) = LowIncentives(i + 10)
            i = i + 1
        Loop
        i = 0
        Do While i < 10
            last20(i + 10) = HighIncentives(i + 10)
            i = i + 1
        Loop
        last20.ToArray
        Shuffle(last20)


        ' Now the Extraction randomization
        Dim j As Integer = 0
        Dim r As New Random
        Dim rand As New Random
        Dim k As Integer
        Dim lagweight As Single = 0.5
        Dim spread As Single = 22
        Randomize()
        Dim Value1 As Integer
        Value1 = 100
        Dim value As Single
        value = Value1
        For k = 1 To 80
            Dim u1 As Double = 1.0 - Rnd()
            Dim u2 As Double = 1.0 - Rnd()
            value = Value1 + Round(lagweight * Round(value - Value1)) + Round(Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2) * spread)
            If value > 200 Then
                value = 200
            End If
            If value < 0 Then
                value = 0
            End If
            writeINI(sSetupFile, "EXtask ", k, value)
        Next

        ' Select which is green and not for each task
        ' SECTION TO WRITE THE RANDOMIZATION INTO THE SETUP FILE
        ' Now write out the setup files,
        writeINI(sInfoFile, "Info", "userId", subID.Text)

        ' showup fee
        writeINI(sSetupFile, "MAIN", "showup", ShowUp)

        '  Now ship out the task information

        Dim qid(40) As String
        Dim prizeA1(40) As String
        Dim probA1(40) As String
        Dim prizeA2(40) As String
        Dim probA2(40) As String
        Dim prizeA3(40) As String
        Dim probA3(40) As String
        Dim prizeB1(40) As String
        Dim probB1(40) As String
        Dim prizeB2(40) As String
        Dim probB2(40) As String
        Dim prizeB3(40) As String
        Dim probB3(40) As String
        Dim order_lot(40) As String
        Dim lotset(40) As String
        Dim pair(40) As String
        Dim loss(40) As String
        Dim endowment(40) As String
        Dim mixed(40) As String
        Dim lottery(40) As String


        Using sr As New StreamReader("lotteries.txt")
            i = 0
            While Not sr.EndOfStream
                Dim splits As String() = sr.ReadLine.Split(","c)
                qid(i) = splits(1)
                prizeA1(i) = splits(2)
                probA1(i) = splits(3)
                prizeA2(i) = splits(4)
                probA2(i) = splits(5)
                prizeA3(i) = splits(6)
                probA3(i) = splits(7)
                prizeB1(i) = splits(8)
                probB1(i) = splits(9)
                prizeB2(i) = splits(10)
                probB2(i) = splits(11)
                prizeB3(i) = splits(12)
                probB3(i) = splits(13)
                order_lot(i) = splits(14)
                lotset(i) = splits(15)
                pair(i) = splits(16)
                loss(i) = splits(17)
                endowment(i) = splits(19)
                mixed(i) = splits(18)
                lottery(i) = splits(0)
                i = i + 1
            End While

        End Using

        ' the RA tasks
        j = 0
        Dim z As Integer
        Do While j < 16
            z = RaTasksG(j)
            writeINI(sSetupFile, "RAtask " & j + 1, "ProbA1", probA1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "ProbA2", probA2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "ProbA3", probA3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "ProbB1", probB1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "ProbB2", probB2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "ProbB3", probB3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "PrizeA1", prizeA1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "PrizeA2", prizeA2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "PrizeA3", prizeA3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "PrizeB1", prizeB1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "PrizeB2", prizeB2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "PrizeB3", prizeB3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "Lottery", lottery(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "order_lot", order_lot(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "lotset", lotset(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "pair", pair(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "loss", loss(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "endowment", endowment(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "mixed", mixed(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 1, "qid", qid(z - 1))
            j = j + 1
        Loop
        j = 0
        Do While j < 24
            z = RaTasksM(j)
            writeINI(sSetupFile, "RAtask " & j + 17, "ProbA1", probA1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "ProbA2", probA2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "ProbA3", probA3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "ProbB1", probB1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "ProbB2", probB2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "ProbB3", probB3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "PrizeA1", prizeA1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "PrizeA2", prizeA2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "PrizeA3", prizeA3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "PrizeB1", prizeB1(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "PrizeB2", prizeB2(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "PrizeB3", prizeB3(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "Lottery", lottery(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "order_lot", order_lot(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "lotset", lotset(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "pair", pair(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "loss", loss(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "endowment", endowment(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "mixed", mixed(z - 1))
            writeINI(sSetupFile, "RAtask " & j + 17, "qid", qid(z - 1))
            j = j + 1
        Loop

        Dim RPointsI(39) As String
        Dim RprobGI(39) As String
        Dim RpicI(39, 99) As String

        Using sr As New StreamReader("Attention.csv")
            i = 0
            While Not sr.EndOfStream

                Dim splits As String() = sr.ReadLine.Split(","c)
                RPointsI(i) = splits(0)
                RprobGI(i) = splits(1)

                j = 0
                Do While j < 100
                    RpicI(i, j) = splits(j + 2)
                    j = j + 1
                Loop
                i = i + 1


            End While

        End Using

        ' the 40 attention tasks
        j = 0
        z = 0
        Dim q As Integer = 0

        Do While j < 20
            z = first20(j)
            writeINI(sSetupFile, "ATtask " & j + 1, "ImageN", z)
            writeINI(sSetupFile, "ATtask " & j + 1, "Points", RPointsI(z - 1))
            writeINI(sSetupFile, "ATtask " & j + 1, "ProbG", RprobGI(z - 1))
            i = 1
            Do While i < 101
                writeINI(sSetupFile, "ATtask " & j + 1, "pic" & i, RpicI(z - 1, i - 1))
                i = i + 1
            Loop
            j = j + 1
        Loop
        j = 0
        Do While j < 20
            z = last20(j)
            writeINI(sSetupFile, "ATtask " & j + 1, "ImageN", z)
            writeINI(sSetupFile, "ATtask " & j + 21, "Points", RPointsI(z - 1))
            writeINI(sSetupFile, "ATtask " & j + 21, "ProbG", RprobGI(z - 1))
            i = 1
            Do While i < 101
                writeINI(sSetupFile, "ATtask " & j + 21, "pic" & i, RpicI(z - 1, i - 1))
                i = i + 1
            Loop
            j = j + 1
        Loop
        ' Reset tasks to start at the first one
        writeINI(sInfoFile, "RAtask", "Task", 1)
        writeINI(sInfoFile, "EXtask", "Task", 1)
        writeINI(sInfoFile, "ATtask", "Task", 1)

        ' Write setup file
        WriteToFile(Setup1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

        ' Write showupfee to Earnings sheet
        writeINI(sEarningsFile, "EARNINGS", "SHOWUP", ShowUp)
        writeINI(sEarningsFile, "EARNINGS", "ATtask", 0)
        writeINI(sEarningsFile, "EARNINGS", "RAtask", 0)
        writeINI(sEarningsFile, "EARNINGS", "EXtask", 0)

    End Sub

    Private myRand As New Random()
    Public Property ConfigurationManager As Object
    Public Property GridView1 As Object

    ' std Fisher-Yates shuffle
    Private Sub Shuffle(arry() As Integer)
        Dim tmp As Integer
        Dim j As Integer

        For n As Integer = arry.Length - 1 To 0 Step -1
            j = myRand.Next(0, n + 1)
            tmp = arry(j)

            ' swap item(j) and item(n) 
            arry(j) = arry(n)
            arry(n) = tmp
        Next
    End Sub




End Class


