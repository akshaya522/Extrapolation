Public Class QuestionX13

    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Okbutton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown3 As NumericUpDown
    Friend WithEvents Label8 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents Label14 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TilbageButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Okbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TilbageButton = New System.Windows.Forms.Button()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Okbutton
        '
        Me.Okbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Okbutton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Okbutton.Location = New System.Drawing.Point(1026, 407)
        Me.Okbutton.Name = "Okbutton"
        Me.Okbutton.Size = New System.Drawing.Size(103, 37)
        Me.Okbutton.TabIndex = 0
        Me.Okbutton.Text = "OK"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(46, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1094, 41)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "13. What do you expect the 30 year fixed mortgage rate to be one year from now?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
    " " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TilbageButton
        '
        Me.TilbageButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TilbageButton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TilbageButton.Location = New System.Drawing.Point(914, 407)
        Me.TilbageButton.Name = "TilbageButton"
        Me.TilbageButton.Size = New System.Drawing.Size(102, 37)
        Me.TilbageButton.TabIndex = 19
        Me.TilbageButton.Text = "Tilbage"
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown3.Location = New System.Drawing.Point(198, 277)
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(55, 29)
        Me.NumericUpDown3.TabIndex = 48
        Me.NumericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown3.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label8.Location = New System.Drawing.Point(80, 277)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(545, 24)
        Me.Label8.TabIndex = 47
        Me.Label8.Text = "An increase/decrease of                          % over the next 10 years"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(46, 223)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(924, 48)
        Me.Label2.TabIndex = 46
        Me.Label2.Text = "10. CC"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(150, 266)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(357, 35)
        Me.Label3.TabIndex = 45
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Font = New System.Drawing.Font("Garamond", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown2.Location = New System.Drawing.Point(198, 183)
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(55, 29)
        Me.NumericUpDown2.TabIndex = 44
        Me.NumericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown2.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label6.Location = New System.Drawing.Point(80, 183)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(535, 24)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "An increase/decrease of                          % over the next 5 years"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(178, 168)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(551, 55)
        Me.Label7.TabIndex = 42
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(46, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(918, 48)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "10. BB"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.DecimalPlaces = 1
        Me.NumericUpDown1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown1.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown1.Location = New System.Drawing.Point(233, 76)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {10, 0, 0, -2147483648})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(65, 26)
        Me.NumericUpDown1.TabIndex = 40
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown1.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(147, 133)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(357, 35)
        Me.Label14.TabIndex = 38
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Garamond", 15.75!)
        Me.Label9.Location = New System.Drawing.Point(71, 78)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(535, 24)
        Me.Label9.TabIndex = 49
        Me.Label9.Text = "An increase/decrease of                          % over the next 5 years"
        '
        'QuestionX12b
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1141, 472)
        Me.ControlBox = False
        Me.Controls.Add(Me.NumericUpDown3)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.NumericUpDown2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TilbageButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Okbutton)
        Me.Controls.Add(Me.Label9)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "QuestionX12b"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                           "GetPrivateProfileStringA" (ByVal lpApplicationName _
                           As String, ByVal lpKeyName As String, ByVal lpDefault _
                           As String, ByVal lpReturnedString As String, ByVal _
                           nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub

    Public choiceA As Byte = 0
    Public choiceB As Byte = 0
    Public choiceC As Byte = 0
    Public choiceOK As Byte = 0



    Private Sub Okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Okbutton.Click

        If choiceA = 0 Then
            MsgBox("Please make selection for A", MsgBoxStyle.OkOnly, "")
            Exit Sub
        End If

        If choiceB = 0 Then
            choiceOK = 1

            Dim valueA As Single = Math.Round(Me.NumericUpDown1.Value * 10) / 10
            Dim valueAH As Single = Math.Round(Me.NumericUpDown1.Value * 10 + 10) / 10
            Dim valueAL As Single = Math.Round(Me.NumericUpDown1.Value * 10 - 10) / 10

            Label5.Text = "B.  How likely is it that the interest rate will be between " & valueAL & "% and " & valueAH & "% one year from now."
            Label2.Text = "C.  How likely is it that the interest rate will above " & valueAH & "% one year from now"

            Label9.Text = "An interest rate of               % one year from now"
            Label6.Text = "There is a                  % probability"
            Label8.Text = "There is a                  % probability"
            Me.Label2.Visible = True
            Me.Label5.Visible = True
            Me.Label6.Visible = True
            Me.Label8.Visible = True
            NumericUpDown2.Visible = True
            NumericUpDown3.Visible = True
            Exit Sub
        End If

        writeINI("../Quest.ini", "Sp�rgsm�l", "QX13_A", NumericUpDown1.Value)
        writeINI("../Quest.ini", "Sp�rgsm�l", "QX13_B", NumericUpDown2.Value)
        writeINI("../Quest.ini", "Sp�rgsm�l", "QX13_C", NumericUpDown3.Value)

        Dim Forms As New QuestionX14()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()

    End Sub

    Private Sub LoadForm(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim valueA As Single = Convert.ToSingle(sGetINI("../Quest.ini", "Sp�rgsm�l", "QX13_A", "0"))
        Dim valueB As Single = Convert.ToSingle(sGetINI("../Quest.ini", "Sp�rgsm�l", "QX13_B", "0"))
        Dim valueC As Single = Convert.ToSingle(sGetINI("../Quest.ini", "Sp�rgsm�l", "QX13_C", "0"))

        Me.Okbutton.Enabled = False

        Label9.Text = "An interest rate of               % one year from now"
        Me.Label2.Visible = False
        Me.Label5.Visible = False
        Me.Label6.Visible = False
        Me.Label8.Visible = False
        Me.NumericUpDown2.Visible = False
        Me.NumericUpDown3.Visible = False

        Select Case sGetINI("../Quest.ini", "Sp�rgsm�l", "QX13_A", "?")
            Case "?"
            Case Else

                Dim valueAH As Single = Math.Round(Me.NumericUpDown1.Value * 10 + 10) / 10
                Dim valueAL As Single = Math.Round(Me.NumericUpDown1.Value * 10 - 10) / 10
                Label5.Text = "B.  How likely is it that the interest rate will be between " & valueAL & "% and " & valueAH & "% one year from now?"
                Label2.Text = "C.  How likely is it that the interest rate will above " & valueAH & "% one year from now?"
                Me.Label2.Visible = True
                Me.Label5.Visible = True
                Me.Label6.Visible = True
                Me.Label8.Visible = True
                NumericUpDown2.Visible = True
                NumericUpDown3.Visible = True
                Me.Okbutton.Enabled = True
        End Select

    End Sub

    Private Sub TilbageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TilbageButton.Click
        Dim Forms As New QuestionX12()
        Forms.MdiParent = Me.MdiParent
        Forms.Show()
        Me.Close()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
        choiceA = 1

        Me.Okbutton.Enabled = True
        If choiceOK = 1 Then
            Dim valueA As Single = Math.Round(Me.NumericUpDown1.Value * 10) / 10
            Dim valueAH As Single = Math.Round(Me.NumericUpDown1.Value * 10 + 10) / 10
            Dim valueAL As Single = Math.Round(Me.NumericUpDown1.Value * 10 - 10) / 10

            Label5.Text = "B.  How likely is it that the interest rate will be between " & valueAL & "% and " & valueAH & "% one year from now?"
            Label2.Text = "C.  How likely is it that the interest rate will above " & valueAH & "% one year from now?"
            Me.Label2.Visible = True
            Me.Label5.Visible = True
            Me.Label6.Visible = True
            Me.Label8.Visible = True
            NumericUpDown2.Visible = True
            NumericUpDown3.Visible = True
        End If

    End Sub

    Private Sub NumericUpDown2_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown2.ValueChanged
        choiceB = 1
        If choiceA = 1 And choiceB = 1 And choiceC = 1 Then
            Me.Okbutton.Enabled = True
        End If

    End Sub

    Private Sub NumericUpDown3_ValueChanged_1(sender As Object, e As EventArgs) Handles NumericUpDown3.ValueChanged
        choiceC = 1
        If choiceA = 1 And choiceB = 1 And choiceC = 1 Then
            Me.Okbutton.Enabled = True
        End If
    End Sub
End Class
