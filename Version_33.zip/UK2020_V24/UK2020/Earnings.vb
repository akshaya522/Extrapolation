Imports System.Math
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Drawing.Graphics
Imports System.Windows.Forms.PaintEventArgs
Public Class Earnings

    Inherits System.Windows.Forms.Form
    Private sInfoFile As String = "../tmpInfo.ini"
    Private sResultsFile As String = "../tmpResult.ini"
    Private sSetupFile As String = "../tmpSetup.ini"
    Private sEarningsFile As String = "../tmpEarnings.ini"
    Friend WithEvents showup As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents IDlabel As System.Windows.Forms.Label
    Friend WithEvents Okbutton As System.Windows.Forms.Button
    Friend WithEvents ThirdReal As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Private sStageFile As String = "../tmpStage.ini"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Friend WithEvents FirstReal As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SecondReal As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FirstReal = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SecondReal = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.showup = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.IDlabel = New System.Windows.Forms.Label()
        Me.Okbutton = New System.Windows.Forms.Button()
        Me.ThirdReal = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Garamond", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(756, 32)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Your earnings are:"
        '
        'FirstReal
        '
        Me.FirstReal.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FirstReal.Location = New System.Drawing.Point(248, 120)
        Me.FirstReal.Name = "FirstReal"
        Me.FirstReal.Size = New System.Drawing.Size(193, 33)
        Me.FirstReal.TabIndex = 17
        Me.FirstReal.Text = "In the first task"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(22, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(188, 33)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "First task"
        '
        'SecondReal
        '
        Me.SecondReal.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SecondReal.Location = New System.Drawing.Point(248, 170)
        Me.SecondReal.Name = "SecondReal"
        Me.SecondReal.Size = New System.Drawing.Size(193, 33)
        Me.SecondReal.TabIndex = 21
        Me.SecondReal.Text = "In the first task"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 170)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(188, 33)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Second task"
        '
        'showup
        '
        Me.showup.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showup.Location = New System.Drawing.Point(248, 270)
        Me.showup.Name = "showup"
        Me.showup.Size = New System.Drawing.Size(193, 33)
        Me.showup.TabIndex = 29
        Me.showup.Text = "In the first task"
        Me.showup.Visible = False
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(22, 270)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(189, 33)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Deltagelses gevinst"
        '
        'IDlabel
        '
        Me.IDlabel.AutoSize = True
        Me.IDlabel.Font = New System.Drawing.Font("Garamond", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IDlabel.Location = New System.Drawing.Point(23, 9)
        Me.IDlabel.Name = "IDlabel"
        Me.IDlabel.Size = New System.Drawing.Size(60, 18)
        Me.IDlabel.TabIndex = 125
        Me.IDlabel.Text = "IDlabel"
        '
        'Okbutton
        '
        Me.Okbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Okbutton.Enabled = False
        Me.Okbutton.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Okbutton.Location = New System.Drawing.Point(724, 359)
        Me.Okbutton.Name = "Okbutton"
        Me.Okbutton.Size = New System.Drawing.Size(122, 44)
        Me.Okbutton.TabIndex = 0
        Me.Okbutton.Text = "Afslut"
        Me.Okbutton.UseVisualStyleBackColor = False
        '
        'ThirdReal
        '
        Me.ThirdReal.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ThirdReal.Location = New System.Drawing.Point(248, 220)
        Me.ThirdReal.Name = "ThirdReal"
        Me.ThirdReal.Size = New System.Drawing.Size(193, 33)
        Me.ThirdReal.TabIndex = 127
        Me.ThirdReal.Text = "In the first task"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(22, 220)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(189, 33)
        Me.Label6.TabIndex = 126
        Me.Label6.Text = "Third task"
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Font = New System.Drawing.Font("Garamond", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(596, 262)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(122, 44)
        Me.Button1.TabIndex = 128
        Me.Button1.Text = "No ShowUp"
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Font = New System.Drawing.Font("Garamond", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(724, 263)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(122, 44)
        Me.Button2.TabIndex = 129
        Me.Button2.Text = "ShowUp"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(22, 320)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(189, 33)
        Me.Label2.TabIndex = 130
        Me.Label2.Text = "Samlet"
        Me.Label2.Visible = False
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(248, 320)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(193, 33)
        Me.Label7.TabIndex = 131
        Me.Label7.Text = "In the first task"
        Me.Label7.Visible = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(596, 312)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(122, 43)
        Me.Button3.TabIndex = 132
        Me.Button3.Text = "After Tax"
        Me.Button3.Visible = False
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(460, 70)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(129, 33)
        Me.Label8.TabIndex = 133
        Me.Label8.Text = "After tax"
        Me.Label8.Visible = False
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(460, 120)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(129, 33)
        Me.Label9.TabIndex = 134
        Me.Label9.Text = "In the first task"
        Me.Label9.Visible = False
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(460, 170)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(129, 33)
        Me.Label10.TabIndex = 135
        Me.Label10.Text = "In the first task"
        Me.Label10.Visible = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(460, 220)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(129, 33)
        Me.Label11.TabIndex = 136
        Me.Label11.Text = "In the first task"
        Me.Label11.Visible = False
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(460, 270)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(129, 33)
        Me.Label12.TabIndex = 137
        Me.Label12.Text = "In the first task"
        Me.Label12.Visible = False
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(460, 320)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(129, 33)
        Me.Label13.TabIndex = 138
        Me.Label13.Text = "In the first task"
        Me.Label13.Visible = False
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Garamond", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(595, 220)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(251, 33)
        Me.Label14.TabIndex = 139
        Me.Label14.Text = "Showup fee - 10 sided dice"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Earnings
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(858, 415)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ThirdReal)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.IDlabel)
        Me.Controls.Add(Me.showup)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.SecondReal)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.FirstReal)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Okbutton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Earnings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region


    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                                "GetPrivateProfileStringA" (ByVal lpApplicationName _
                                As String, ByVal lpKeyName As String, ByVal lpDefault _
                                As String, ByVal lpReturnedString As String, ByVal _
                                nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub

    Private Sub Okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Okbutton.Click

        Dim returnPSW As String = "1"
        Dim passwordString As String = "Enter password"
        Dim password As String = "0"
        If password <> "" Then
            Do While password <> returnPSW
                returnPSW = InputBox(passwordString, "Password", "", 100, 100)
            Loop
        End If

        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        Me.IDlabel.Text = "ID: " & userId
        Dim RAEarnings As String = sGetINI(sEarningsFile, "EARNINGS", "RAtask", "0") & " kr."
        Dim ATEarnings As String = sGetINI(sEarningsFile, "EARNINGS", "ATtask", "0") & " kr."
        Dim EXEarnings As String = sGetINI(sEarningsFile, "EARNINGS", "EXtask", "0") & " kr."
        If RAEarnings = " kr." Then RAEarnings = "0 kr."
        If ATEarnings = " kr." Then RAEarnings = "0 kr."
        If EXEarnings = " kr." Then RAEarnings = "0 kr."
        WriteToFile(userId, EXEarnings, ATEarnings, RAEarnings, Me.showup.Text)
        Me.Close()
        If Application.OpenForms.Count = 1 Then

            Application.Exit()

        End If


    End Sub

    Private Sub IDREQUEST_(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        Me.IDlabel.Text = "ID: " & userId

        Dim ShowUp As String = sGetINI(sEarningsFile, "EARNINGS", "SHOWUP", "0") & " kr."
        Dim RAEarnings As String = sGetINI(sEarningsFile, "EARNINGS", "RAtask", "0")
        Dim ATEarnings As String = sGetINI(sEarningsFile, "EARNINGS", "ATtask", "0")
        Dim EXEarnings As String = sGetINI(sEarningsFile, "EARNINGS", "EXtask", "0")

        Me.showup.Text = ShowUp
        Me.showup.Visible = False

        Me.FirstReal.Text = EXEarnings & " kr."
        Me.SecondReal.Text = RAEarnings & " kr."
        Me.ThirdReal.Text = ATEarnings & " kr."
        Me.Label9.Visible = False
        Me.Label10.Visible = False
        Me.Label11.Visible = False
        Me.Label12.Visible = False
        Me.Label13.Visible = False
        Me.Label14.Visible = False


    End Sub

    Public SUfee As Integer = 0

    Private Sub WriteToFile(ByVal userID As String,
                          ByVal Earnings1 As String,
                          ByVal Earnings2 As String,
                          ByVal Earnings3 As String,
                          ByVal Earnings4 As String)

        Dim empty As String = 999

        Dim sFile As StreamWriter
        Dim line As String
        Dim sDate, sTime As String
        sDate = DateString
        sTime = TimeString
        sFile = File.AppendText("../Data/EA_" & userID & ".txt")
        line = userID & ";" & sDate & ";" & sTime & ";" &
                Earnings1 & ";" & Earnings2 & ";" & Earnings3 & ";" & Earnings4
        sFile.WriteLine(line)
        sFile.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        SUfee = 0

        Me.showup.Visible = True
        Dim RAEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "RAtask", "0"))
        Dim ATEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "ATtask", "0"))
        Dim EXEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "EXtask", "0"))
        Me.showup.Text = "0 kr."
        writeINI(sEarningsFile, "EARNINGS", "SUtask", 0)
        Label2.Visible = True
        Label5.Visible = True
        Label7.Visible = True
        Button3.Enabled = True
        Button3.Visible = True
        Label7.Text = RAEarnings + ATEarnings + EXEarnings & " kr."

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Me.showup.Visible = True
        Dim RAEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "RAtask", "0"))
        Dim ATEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "ATtask", "0"))
        Dim EXEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "EXtask", "0"))
        Dim ShowUp As Single
        ShowUp = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "SHOWUP", "0"))
        SUfee = ShowUp
        Me.showup.Text = ShowUp & " kr."

        writeINI(sEarningsFile, "EARNINGS", "SUtask", 0)
        Label2.Visible = True
        Label5.Visible = True
        Label7.Visible = True
        Button3.Enabled = True
        Button3.Visible = True
        Label7.Text = RAEarnings + ATEarnings + EXEarnings + ShowUp & " kr."


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim RAEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "RAtask", "0"))
        Dim ATEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "ATtask", "0"))
        Dim EXEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "EXtask", "0"))
        Dim SUEarnings As Single = Convert.ToSingle(sGetINI(sEarningsFile, "EARNINGS", "SUtask", 0))

        Dim EXEarningsTax As Single
        Dim RAEarningsTax As Single
        Dim ATEarningsTax As Single
        Dim ShowUpTax As Single

        Me.Label8.Visible = True

        Me.Label9.Visible = True
        If EXEarnings < 200 Then
            Me.Label9.Text = EXEarnings & " kr."
            EXEarningsTax = EXEarnings
        Else
            Me.Label9.Text = 200 + (EXEarnings - 200) * (1 - 0.175) & " kr."
            EXEarningsTax = 200 + (EXEarnings - 200) * (1 - 0.175)
        End If
        Me.Label10.Visible = True
        If RAEarnings < 200 Then
            Me.Label10.Text = RAEarnings & " kr."
            RAEarningsTax = RAEarnings
        Else
            Me.Label10.Text = 200 + (RAEarnings - 200) * (1 - 0.175) & " kr."
            RAEarningsTax = 200 + (RAEarnings - 200) * (1 - 0.175)
        End If
        Me.Label11.Visible = True
        If ATEarnings < 200 Then
            Me.Label11.Text = ATEarnings & " kr."
            ATEarningsTax = ATEarnings
        Else
            Me.Label11.Text = 200 + (ATEarnings - 200) * (1 - 0.175) & " kr."
            ATEarningsTax = 200 + (ATEarnings - 200) * (1 - 0.175)
        End If
        Me.Label12.Visible = True
        If SUfee < 200 Then
            Me.Label12.Text = SUfee & " kr."
            ShowUpTax = SUfee
        Else
            Me.Label12.Text = 200 + (SUfee - 200) * (1 - 0.175) & " kr."
            ShowUpTax = 200 + (SUfee - 200) * (1 - 0.175)
        End If

        Label13.Visible = True
        Label13.Text = RAEarningsTax + ATEarningsTax + EXEarningsTax + ShowUpTax & " kr."
        Okbutton.Visible = True
        Okbutton.Enabled = True


    End Sub
End Class
