﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports System.IO
Imports System.Math

Public Class DK_EXTRACT2
    'Inherits System.Windows.Forms.Form
    Private sInfoFile As String = "../tmpInfo.ini"
    Private sResultsFile As String = "../tmpResult.ini"
    Private sSetupFile As String = "../tmpSetup.ini"
    Private sEarningsFile As String = "../tmpEarnings.ini"
    Private sStageFile As String = "../tmpStage.ini"
    Dim dt As New DataTable
    Dim ran As New Random
    Public decision As Integer = 41

    Private FixHeight As Integer = 1024
    Private FixWidth As Integer = 1024

    Declare Function GetPrivateProfileString Lib "kernel32" Alias _
                             "GetPrivateProfileStringA" (ByVal lpApplicationName _
                             As String, ByVal lpKeyName As String, ByVal lpDefault _
                             As String, ByVal lpReturnedString As String, ByVal _
                             nSize As Integer, ByVal lpFileName As String) As Integer


    Declare Function WritePrivateProfileString Lib "kernel32" Alias _
                        "WritePrivateProfileStringA" (ByVal lpApplicationName _
                        As String, ByVal lpKeyName As String, ByVal lpString As String,
                        ByVal lpFileName As String) As Integer


    Public Shared Function sGetINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                            As String, ByVal sDefault As String) As String

        Dim sTemp As String = Space(255)
        Dim nLength As Integer

        nLength = GetPrivateProfileString(sSection, sKey, sDefault, sTemp,
        255, sINIFile)
        Return sTemp.Substring(0, nLength)
    End Function

    Public Shared Sub writeINI(ByVal sINIFile As String, ByVal sSection As String, ByVal sKey _
                        As String, ByVal sValue As String)

        'Remove CR/LF characters
        sValue = sValue.Replace(vbCr, vbNullChar)
        sValue = sValue.Replace(vbLf, vbNullChar)

        'Write information to INI file
        WritePrivateProfileString(sSection, sKey, sValue, sINIFile)

    End Sub
    Dim nextpredict As Single = 100
    Dim moved As Single = 0
    Dim datapoint As Integer = 1
    Dim txtVal As Integer = 1
    Dim predict1(39) As Integer

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        Me.Size = New Size(1450, 900)

        ' Find out which lottery is played
        Dim Task As Integer = sGetINI(sInfoFile, "EXtask", "Task", 1)
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")

        Me.IDlabel.Text = "ID: " & userId
        Me.Header.Text = "Price of the asset over time"

        Dim custom As New CustomLabel
        custom.FromPosition = 2
        custom.ToPosition = 80
        custom.Text = "1"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom)

        Dim custom1 As New CustomLabel
        custom1.FromPosition = 10
        custom1.ToPosition = 80
        custom1.Text = "5"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom1)

        Dim custom9 As New CustomLabel
        custom9.FromPosition = 20
        custom9.ToPosition = 80
        custom9.Text = "10"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom9)

        Dim custom14 As New CustomLabel
        custom14.FromPosition = 30
        custom14.ToPosition = 80
        custom14.Text = "15"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom14)

        Dim custom20 As New CustomLabel
        custom20.FromPosition = 40
        custom20.ToPosition = 80
        custom20.Text = "20"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom20)

        Dim custom25 As New CustomLabel
        custom25.FromPosition = 50
        custom25.ToPosition = 80
        custom25.Text = "25"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom25)

        Dim custom30 As New CustomLabel
        custom30.FromPosition = 60
        custom30.ToPosition = 80
        custom30.Text = "30"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom30)

        Dim custom35 As New CustomLabel
        custom35.FromPosition = 70
        custom35.ToPosition = 80
        custom35.Text = "35"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom35)

        Dim custom40 As New CustomLabel
        custom40.FromPosition = 80
        custom40.ToPosition = 81
        custom40.Text = "40"
        Chart1.ChartAreas(0).AxisX.CustomLabels.Add(custom40)


        Chart1.Series("1").ChartType = SeriesChartType.Line
        Chart1.Series("1").Color = Color.Black
        Chart1.Series("1").MarkerColor = Color.DarkOliveGreen
        Chart1.Series("1").MarkerBorderColor = Color.Black
        Chart1.Series("1").MarkerStyle = MarkerStyle.Circle
        Chart1.Series("1").Font = New System.Drawing.Font("Garamond", 11, System.Drawing.FontStyle.Bold)
        Chart1.Series("1").MarkerSize = 10
        Chart1.Series("1").XValueMember = "X"
        Chart1.Series("1").YValueMembers = "Y"

        ' HELP - SET THE LABEL NUMBERS SMALLER
        Chart1.Series("2").ChartType = SeriesChartType.Point
        Chart1.Series("2").MarkerBorderColor = Color.Aquamarine
        Chart1.Series("2").MarkerColor = Color.Aquamarine
        Chart1.Series("2").MarkerSize = 14
        Chart1.Series("2").MarkerStyle = MarkerStyle.Cross
        Chart1.Series("2").XValueMember = "X"
        Chart1.Series("2").YValueMembers = "Y"


        Chart1.Series("3").ChartType = SeriesChartType.Point
        Chart1.Series("3").MarkerBorderColor = Color.DimGray
        Chart1.Series("3").MarkerColor = Color.DimGray
        Chart1.Series("3").MarkerSize = 12
        Chart1.Series("3").MarkerStyle = MarkerStyle.Star4
        Chart1.Series("3").XValueMember = "X"
        Chart1.Series("3").YValueMembers = "Y"

        Chart1.ChartAreas(0).AxisX.LabelStyle.Interval = 5
        Chart1.ChartAreas(0).AxisX.LabelAutoFitMinFontSize = 5
        Chart1.ChartAreas(0).AxisY.LabelAutoFitMinFontSize = 5
        Chart1.ChartAreas(0).AxisX.Minimum = 0
        Chart1.ChartAreas(0).AxisX.Maximum = 80
        Chart1.ChartAreas(0).AxisY.MajorGrid.LineColor = Color.LightBlue
        Chart1.ChartAreas(0).AxisY.Maximum = 200
        Chart1.ChartAreas(0).AxisY.Minimum = 0
        Chart1.ChartAreas(0).AlignmentStyle = AreaAlignmentStyles.Position
        Chart1.ChartAreas(0).BackColor = Color.FromArgb(255, 255, 255)

        ' show first data point
        AddHandler Chart1.MouseDown, AddressOf Chart_MouseDown
        AddHandler Chart1.MouseMove, AddressOf Chart_MouseMove
        Me.Button1.Enabled = False

        Me.Button4.Enabled = False
        Me.Button4.Visible = False
        Me.NumericUpDown1.Visible = False
        Me.Button5.Enabled = False
        Me.Button2.Visible = False
        Me.Button2.Enabled = False
        Me.Button5.Visible = False
        Me.Label1.Visible = False
        Me.Label5.Visible = False
        Me.Label6.Visible = False
        Me.Label7.Visible = False

        Label3.Visible = False
    End Sub

    ' NEED HELP GETTING THIS TO WORK AGAIN  (THIS CAUSES A LOT OF ERRORS)
    Sub SetY(ByVal ch As Chart, ByVal e_X As Integer, ByVal e_Y As Integer)
        Try
            If e_X >= 0 And e_X < Chart1.Width And e_Y >= 0 And e_Y < Chart1.Height Then
                Dim currentx As Integer = ch.ChartAreas(0).AxisX.PixelPositionToValue(e_X)
                If currentx < decision Or currentx > ch.ChartAreas(0).AxisX.Maximum Then
                    currentx = -1
                End If
                Dim currenty As Integer = ch.ChartAreas(0).AxisY.PixelPositionToValue(e_Y)
                If currenty < ch.ChartAreas(0).AxisY.Minimum Or currenty > ch.ChartAreas(0).AxisY.Maximum Then
                    currenty = -1

                End If
                If currentx > -1 And currenty > -1 Then
                    ch.Series("2").Points.FindByValue(currentx, "X").SetValueY(currenty)
                    ch.Invalidate()
                    moved = 1
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    ' NEED HELP GETTING THIS TO WORK AGAIN
    Public Sub Chart_MouseDown(sender As Object, e As MouseEventArgs)
        If e.Button = Windows.Forms.MouseButtons.Left Then
            SetY(CType(sender, Chart), e.X, e.Y)
        End If
    End Sub

    ' NEED HELP GETTING THIS TO WORK AGAIN
    Public Sub Chart_MouseMove(sender As Object, e As MouseEventArgs)
        If e.Button = Windows.Forms.MouseButtons.Left Then
            SetY(CType(sender, Chart), e.X, e.Y)
        End If
    End Sub

    Public Sub Button2_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Task As Integer = sGetINI(sInfoFile, "EXtask", "Task", 1)
        Dim strtemp As String = "EXtask"

        ' Dim lottery information
        Dim choice1 As Single = 0
        choice1 = Chart1.Series("2").Points.FindByValue(decision, "X").YValues(0)
        Dim choice2 As Single = 0
        choice2 = Chart1.Series("2").Points.FindByValue(decision + 1, "X").YValues(0)

        predict1(Task - 1) = choice1

        ' This case should be reversed when the moving of the crosses works
        Select Case moved
            Case 0
                Dim ChoiceTxt As String = "Please make prediction"
                MsgBox(ChoiceTxt, MsgBoxStyle.OkOnly, "")
                Exit Sub
            Case Else
        End Select

        ' Write to Temporary ResultsFile
        writeINI(sResultsFile, "Decision", Task, decision)

        ' Now update to the next task
        writeINI(sInfoFile, "EXtask", "Task", Task + 1)

        txtVal = txtVal + 1

        'check if there is another task
        If Task < 40 Then
            movedecision(Task)
            Dim realization As Single = 0
            realization = Chart1.Series("1").Points.FindByValue(decision, "X").YValues(0)

            WriteToFile("EX", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, decision, choice1, choice2, realization, 0, 0, 0, 0, 0)

            Task = Task + 1
            decision = decision + 1
            moved = 0

        Else
            Dim j As Integer = sGetINI(sSetupFile, "EXtask", Task, 1)
            Chart1.Series("1").Points.AddXY(decision, j)

            ' replace the prediction by the locked diamond
            choice1 = Chart1.Series("2").Points.FindByValue(decision, "X").YValues(0)
            Chart1.Series("3").Points.AddXY(decision, choice1)
            Dim realization As Single = 0
            realization = Chart1.Series("1").Points.FindByValue(decision, "X").YValues(0)
            WriteToFile("EX", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, decision, choice1, 0, realization, 0, 0, 0, 0, 0)

            ' REMOVE THE OLD PREDICTION
            Chart1.Series("2").Points.Clear()
            Chart1.Update()
            Me.Button1.Enabled = False
            Me.Button4.Enabled = True
            Me.Button4.Visible = True
            Me.NumericUpDown1.Visible = True
            Me.Button5.Enabled = True
            Me.Button2.Visible = True
            Me.Button2.Enabled = True
            Me.Button5.Visible = True
            Me.Label3.Visible = True


            moved = 0

        End If

    End Sub
    Sub movedecision(Task As Integer)

        ' First insert the realization of the prediction
        Dim j As Integer = sGetINI(sSetupFile, "EXtask", Task + 40, 1)
        Chart1.Series("1").Points.AddXY(Task + 40, j)


        Dim myColorY As New Color
        myColorY = ColorTranslator.FromHtml("#FFC20A")
        Dim myColorB As New Color
        myColorB = ColorTranslator.FromHtml("#0C7BDC")

        ' replace the prediction by the locked diamond
        Dim choice As Single = 0
        choice = Chart1.Series("2").Points.FindByValue(Task + 41, "X").YValues(0)

        Chart1.Series("3").Points.Clear()

        Chart1.Series("3").Points.AddXY(Task + 41, choice)

        ' REMOVE THE OLD PREDICTION
        Chart1.Series("2").Points.Clear()

        ' THEN ADD THE NEW PREDICTION
        ' insert new prediction to make
        Chart1.Series("2").Points.AddXY(Task + 41, 100)
        Chart1.Series("2").Points.AddXY(Task + 42, 100)

        Chart1.Series("2").Points.FindByValue(Task + 41, "X").MarkerColor = myColorB
        Chart1.Series("2").Points.FindByValue(Task + 41, "X").MarkerBorderColor = myColorB
        Chart1.Series("2").Points.FindByValue(Task + 42, "X").MarkerColor = myColorY
        Chart1.Series("2").Points.FindByValue(Task + 42, "X").MarkerBorderColor = Color.Black

        ' Chart1.Series("2").Points.Remove(decision + 39, 1)
        Chart1.Update()

        Label7.Text = txtVal & " of 40"



    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim myColorY As New Color
        myColorY = ColorTranslator.FromHtml("#FFC20A")
        Dim myColorB As New Color
        myColorB = ColorTranslator.FromHtml("#0C7BDC")

        Chart1.Series("1").Points.AddXY(0, 100)
        For i As Integer = 1 To 40
            Dim j As Integer = sGetINI(sSetupFile, "EXtask", i, 1)
            Chart1.Series("1").Points.AddXY(i, j)
            Chart1.Update()
            WriteToFile("EX", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, i, 0, 0, j, 0, 0, 0, 0, 0)
            Threading.Thread.Sleep(90)
        Next
        Me.Button3.Enabled = False
        Me.Label4.Visible = False
        Me.Button1.Enabled = True
        Me.Label6.Visible = True
        Me.Label7.Visible = True
        Me.Button3.Visible = False
        Chart1.Series("2").Points.AddXY(41, 100)
        Chart1.Series("2").Points.FindByValue(41, "X").MarkerColor = myColorB
        Chart1.Series("2").Points.FindByValue(41, "X").MarkerBorderColor = myColorB
        Chart1.Series("2").Points.AddXY(42, 100)
        Chart1.Series("2").Points.FindByValue(42, "X").MarkerColor = myColorY
        Chart1.Series("2").Points.FindByValue(42, "X").MarkerBorderColor = Color.Black
        Me.Header.Text = "Price of asset over time"

        Label7.Text = "1 of 40"

    End Sub

    Private Sub WriteToFile(ByVal TaskId As String,
                            ByVal Decision As String,
                            ByVal PrizeA1 As Single,
                            ByVal PrizeA2 As Single,
                            ByVal PrizeA3 As Single,
                            ByVal PrizeB1 As Single,
                            ByVal PrizeB2 As Single,
                            ByVal PrizeB3 As Single,
                            ByVal ProbA1 As Single,
                            ByVal ProbA2 As Single,
                            ByVal ProbA3 As Single,
                            ByVal ProbB1 As Single,
                            ByVal ProbB2 As Single,
                            ByVal ProbB3 As Single,
                            ByVal Endowment As Single,
                            ByVal qid As String,
                            ByVal Mixed As Single,
                            ByVal Loss As Single,
                            ByVal LotSet As Single,
                            ByVal Pair As Single,
                            ByVal ChoiceA As Single,
                            ByVal ChoiceB As Single,
        ByVal ImageN As Single,
        ByVal ProbG As Single,
                            ByVal Points As Single,
                            ByVal pickedprob As Single,
                            ByVal period As Single,
                            ByVal choice1 As Single,
                            ByVal choice2 As Single,
                            ByVal realization As Single,
                            ByVal Question As String,
                            ByVal answer As String,
                            ByVal roll40 As Single,
                            ByVal roll100 As Single,
                            ByVal earnings As Single
                            )

        Dim empty As String = 999

        Dim sFile As StreamWriter
        Dim line As String
        Dim sDate, sTime As String
        sDate = DateString
        sTime = TimeString
        Dim userId As String = sGetINI(sInfoFile, "Info", "userId", "0000")
        sFile = File.AppendText("../Data/EX_" & userId & ".txt")
        line = userId & ";" & sDate & ";" & sTime & ";" & TaskId & ";" & Decision & ";" &
            PrizeA1 & ";" & PrizeA2 & ";" & PrizeA3 & ";" & PrizeB1 & ";" & PrizeB2 & ";" & PrizeB3 & ";" &
ProbA1 & ";" & ProbA2 & ";" & ProbA3 & ";" & ProbB1 & ";" & ProbB2 & ";" & ProbB3 & ";" &
Endowment & ";" & qid & ";" & Mixed & ";" & Loss & ";" & LotSet & ";" & Pair & ";" & ChoiceA & ";" & ChoiceB & ";" &
        ImageN & ";" & ProbG & ";" & Points & ";" & pickedprob & ";" &
        period & ";" & choice1 & ";" & choice2 & ";" & realization & ";" &
        Question & ";" & answer & ";" &
        roll40 & ";" & roll100 & ";" & earnings
        sFile.WriteLine(line)
        sFile.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Me.Label8.Visible = False

        Dim myColorY As New Color
        myColorY = ColorTranslator.FromHtml("#FFC20A")
        Dim myColorB As New Color
        myColorB = ColorTranslator.FromHtml("#0C7BDC")


        Chart1.Series("1").MarkerSize = 10
        Chart1.Series("3").Points.Clear()
        Chart1.Series("3").MarkerSize = 12
        Chart1.Series("3").MarkerBorderColor = myColorB
        Chart1.Series("1").MarkerBorderColor = Color.Black
        Chart1.Series("3").Font = New System.Drawing.Font("Garamond", 11, System.Drawing.FontStyle.Bold)
        Chart1.Series("1").Font = New System.Drawing.Font("Garamond", 11, System.Drawing.FontStyle.Bold)
        Chart1.Update()

        ' Dim lottery information

        Dim choiceN As Single
        choiceN = NumericUpDown1.Value
        ' First plot all of them: 
        For i As Integer = 1 To 40
            Chart1.Series("3").Points.AddXY(i + 40, predict1(i - 1))
            Chart1.Series("3").Points.FindByValue(i + 40, "X").MarkerBorderColor = myColorB
            Chart1.Series("3").Points.FindByValue(i + 40, "X").MarkerSize = 12
            Chart1.Series("1").Points.FindByValue(i + 40, "X").MarkerBorderColor = Color.Black
            Chart1.Series("1").Points.FindByValue(i + 40, "X").MarkerSize = 10
            Chart1.Series("3").Points.FindByValue(i + 40, "X").Font = New System.Drawing.Font("Garamond", 11, System.Drawing.FontStyle.Bold)
            Chart1.Series("1").Points.FindByValue(i + 40, "X").Font = New System.Drawing.Font("Garamond", 11, System.Drawing.FontStyle.Bold)
            If choiceN = i Then
                Chart1.Series("3").Points.FindByValue(choiceN + 40, "X").Font = New System.Drawing.Font("Garamond", 18, System.Drawing.FontStyle.Bold)
                Chart1.Series("1").Points.FindByValue(choiceN + 40, "X").Font = New System.Drawing.Font("Garamond", 18, System.Drawing.FontStyle.Bold)
                Chart1.Series("3").Points.FindByValue(choiceN + 40, "X").MarkerBorderColor = Color.Orange
                Chart1.Series("1").Points.FindByValue(choiceN + 40, "X").MarkerBorderColor = Color.Orange
                Chart1.Series("3").Points.FindByValue(choiceN + 40, "X").MarkerSize = 20
                Chart1.Series("1").Points.FindByValue(choiceN + 40, "X").MarkerSize = 20

            End If
            Chart1.Update()
            Threading.Thread.Sleep(60)
        Next

        Dim predict As Single
        predict = Chart1.Series("3").Points.FindByValue(choiceN + 40, "X").YValues(0)

        Dim outcome As Single
        outcome = Chart1.Series("1").Points.FindByValue(choiceN + 40, "X").YValues(0)

        Dim Chance As Integer
        Chance = (100 - 5 * Math.Abs(outcome - predict))
        If Chance < 0 Then Chance = 0
        Label7.Text = NumericUpDown1.Value & " of 40"
        Label1.Visible = True
        Label5.Visible = True
        Label1.Text = "You predicted the value to be: " & predict & " and the outcome was: " & outcome
        Label5.Text = "You have a " & Chance & "% chance of winning 2000 kr."
        If Chance > 0 Then
            Label8.Text = "A die roll from 1 to " & Chance & "wins you 2000 kr."
            NumericUpDown2.Visible = True
            Label2.Visible = True
            Button7.Visible = True

        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        If MsgBoxResult.Cancel = MsgBox("Is this correct?", MsgBoxStyle.OkCancel, "No payment") Then
            Exit Sub
        End If
        writeINI(sEarningsFile, "EARNINGS", "EXtask", 0)
        Dim returnPSW As String = "1"
        Dim passwordString As String = "Indtast adgangskode"
        Dim password As String = "0"
        If password <> "" Then
            Do While password <> returnPSW
                returnPSW = InputBox(passwordString, "Adgangskode", "", 100, 100)
            Loop
        End If
        writeINI(sStageFile, "Stage", "Stage", "LOT")
        Dim DK2020 As New BeforeLOT
        DK2020.MdiParent = Me.MdiParent
        Me.Close()
        DK2020.Show()

    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        Dim choiceN As Single
        choiceN = NumericUpDown1.Value + 40

        Dim predict As Single
        predict = Chart1.Series("3").Points.FindByValue(choiceN, "X").YValues(0)

        Dim outcome As Single
        outcome = Chart1.Series("1").Points.FindByValue(choiceN, "X").YValues(0)

        Dim Chance As Integer
        Chance = (100 - 5 * Math.Abs(outcome - predict))
        If Chance < 0 Then Chance = 0
        ' Get basic lottery
        Dim amount As String
        Dim temprolld As Integer
        temprolld = NumericUpDown2.Value

        If temprolld <= Chance Then
            amount = Convert.ToString(2000) & " kr."
            writeINI(sEarningsFile, "EARNINGS", "EXtask", 2000)
            WriteToFile("EXearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, choiceN, temprolld, 2000)
        Else
            amount = "0 kr."
            writeINI(sEarningsFile, "EARNINGS", "EXtask", 0)
            WriteToFile("EXearn", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, choiceN, temprolld, 0)

        End If

        If MsgBoxResult.Cancel = MsgBox("Your earnings are " & amount, MsgBoxStyle.OkCancel, "Payment") Then
            Exit Sub
        End If

        Dim returnPSW As String = "1"
        Dim passwordString As String = "Indtast adgangskode"
        Dim password As String = "0"
        If password <> "" Then
            Do While password <> returnPSW
                returnPSW = InputBox(passwordString, "Adgangskode", "", 100, 100)
            Loop
        End If
        writeINI(sStageFile, "Stage", "Stage", "LOT")
        Dim DK2020 As New BeforeLOT
        DK2020.MdiParent = Me.MdiParent
        Me.Close()
        DK2020.Show()

    End Sub

    Dim counter As Integer = 0
    Private Sub Button6_Click(sender As Object, e As EventArgs)
        counter = counter + 1
        If (counter / 2 = 0) Then
            Chart1.Series("1").ChartType = SeriesChartType.Line
        End If

        Chart1.Series("1").ChartType = SeriesChartType.Point

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        Dim choiceN As Single
        choiceN = NumericUpDown1.Value + 40

        Dim predict As Single
        predict = Chart1.Series("3").Points.FindByValue(choiceN, "X").YValues(0)

        Dim outcome As Single
        outcome = Chart1.Series("1").Points.FindByValue(choiceN, "X").YValues(0)

        Dim Chance As Integer
        Chance = (100 - 5 * Math.Abs(outcome - predict))
        If Chance < 0 Then
            Chance = 0
        End If


        Dim DieRoll As Integer = Me.NumericUpDown2.Value
        If DieRoll <= Chance Then
            Label8.Text = "The die roll was between 1 and " & Chance & ": You win 2000 kr."
        Else
            Label8.Text = "The die roll was larger than " & Chance & " : You win 0 kr."
        End If

        Label1.Text = "You predicted the value to be: " & predict & " and the outcome was: " & outcome
        Label5.Text = "You have a " & Chance & "% chance of winning 2000 kr."


        Label8.Visible = True

    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub
End Class



